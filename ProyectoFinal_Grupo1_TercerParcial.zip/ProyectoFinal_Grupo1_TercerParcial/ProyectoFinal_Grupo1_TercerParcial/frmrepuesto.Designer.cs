﻿namespace ProyectoFinal_Grupo1_TercerParcial
{
    partial class Frmrepuesto
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmrepuesto));
            lbltitulo = new Label();
            lblid = new Label();
            lblnombre = new Label();
            lblprecio = new Label();
            lbldescripcion = new Label();
            lblcantidad = new Label();
            lblproveedor = new Label();
            lblfechaingreso = new Label();
            lblmarca = new Label();
            txtnombrerepuesto = new TextBox();
            txtidrepuesto = new TextBox();
            txtprecio = new TextBox();
            txtproveedor = new TextBox();
            txtcantidad = new TextBox();
            txtmodelo = new TextBox();
            txtfechaingreso = new TextBox();
            txtdescripcion = new TextBox();
            btnguardarrepuesto = new Button();
            btneliminarrepuesto = new Button();
            btnbuscarrepuesto = new Button();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // lbltitulo
            // 
            lbltitulo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lbltitulo.AutoSize = true;
            lbltitulo.BackColor = Color.Black;
            lbltitulo.BorderStyle = BorderStyle.Fixed3D;
            lbltitulo.Font = new Font("Britannic Bold", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltitulo.ForeColor = Color.FromArgb(224, 224, 224);
            lbltitulo.Location = new Point(12, 9);
            lbltitulo.Name = "lbltitulo";
            lbltitulo.Size = new Size(99, 23);
            lbltitulo.TabIndex = 0;
            lbltitulo.Text = "REPUESTO";
            lbltitulo.TextAlign = ContentAlignment.MiddleCenter;
            lbltitulo.Click += lbltitulo_Click;
            // 
            // lblid
            // 
            lblid.AutoSize = true;
            lblid.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblid.Location = new Point(85, 151);
            lblid.Name = "lblid";
            lblid.Size = new Size(25, 15);
            lblid.TabIndex = 1;
            lblid.Text = "ID:";
            // 
            // lblnombre
            // 
            lblnombre.AutoSize = true;
            lblnombre.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblnombre.Location = new Point(151, 86);
            lblnombre.Name = "lblnombre";
            lblnombre.Size = new Size(69, 15);
            lblnombre.TabIndex = 2;
            lblnombre.Text = "NOMBRE:";
            // 
            // lblprecio
            // 
            lblprecio.AutoSize = true;
            lblprecio.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblprecio.Location = new Point(48, 213);
            lblprecio.Name = "lblprecio";
            lblprecio.Size = new Size(62, 15);
            lblprecio.TabIndex = 3;
            lblprecio.Text = "PRECIO:";
            // 
            // lbldescripcion
            // 
            lbldescripcion.AutoSize = true;
            lbldescripcion.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbldescripcion.Location = new Point(134, 352);
            lbldescripcion.Name = "lbldescripcion";
            lbldescripcion.Size = new Size(105, 15);
            lbldescripcion.TabIndex = 4;
            lbldescripcion.Text = "DESCRIPCION:";
            // 
            // lblcantidad
            // 
            lblcantidad.AutoSize = true;
            lblcantidad.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblcantidad.Location = new Point(462, 151);
            lblcantidad.Name = "lblcantidad";
            lblcantidad.Size = new Size(81, 15);
            lblcantidad.TabIndex = 5;
            lblcantidad.Text = "CANTIDAD:";
            // 
            // lblproveedor
            // 
            lblproveedor.AutoSize = true;
            lblproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblproveedor.Location = new Point(25, 291);
            lblproveedor.Name = "lblproveedor";
            lblproveedor.Size = new Size(95, 15);
            lblproveedor.TabIndex = 6;
            lblproveedor.Text = "PROVEEDOR:";
            // 
            // lblfechaingreso
            // 
            lblfechaingreso.AutoSize = true;
            lblfechaingreso.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblfechaingreso.Location = new Point(422, 291);
            lblfechaingreso.Name = "lblfechaingreso";
            lblfechaingreso.Size = new Size(121, 15);
            lblfechaingreso.TabIndex = 7;
            lblfechaingreso.Text = "FECHA INGRESO:";
            // 
            // lblmarca
            // 
            lblmarca.AutoSize = true;
            lblmarca.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblmarca.Location = new Point(462, 213);
            lblmarca.Name = "lblmarca";
            lblmarca.Size = new Size(69, 15);
            lblmarca.TabIndex = 8;
            lblmarca.Text = "MODELO:";
            // 
            // txtnombrerepuesto
            // 
            txtnombrerepuesto.Location = new Point(242, 83);
            txtnombrerepuesto.Name = "txtnombrerepuesto";
            txtnombrerepuesto.Size = new Size(326, 23);
            txtnombrerepuesto.TabIndex = 9;
            // 
            // txtidrepuesto
            // 
            txtidrepuesto.Location = new Point(134, 148);
            txtidrepuesto.Name = "txtidrepuesto";
            txtidrepuesto.Size = new Size(165, 23);
            txtidrepuesto.TabIndex = 10;
            // 
            // txtprecio
            // 
            txtprecio.Location = new Point(134, 213);
            txtprecio.Name = "txtprecio";
            txtprecio.Size = new Size(165, 23);
            txtprecio.TabIndex = 11;
            // 
            // txtproveedor
            // 
            txtproveedor.Location = new Point(134, 288);
            txtproveedor.Name = "txtproveedor";
            txtproveedor.Size = new Size(165, 23);
            txtproveedor.TabIndex = 12;
            // 
            // txtcantidad
            // 
            txtcantidad.Location = new Point(584, 148);
            txtcantidad.Name = "txtcantidad";
            txtcantidad.Size = new Size(165, 23);
            txtcantidad.TabIndex = 13;
            // 
            // txtmodelo
            // 
            txtmodelo.Location = new Point(584, 205);
            txtmodelo.Name = "txtmodelo";
            txtmodelo.Size = new Size(165, 23);
            txtmodelo.TabIndex = 14;
            // 
            // txtfechaingreso
            // 
            txtfechaingreso.Location = new Point(584, 288);
            txtfechaingreso.Name = "txtfechaingreso";
            txtfechaingreso.Size = new Size(165, 23);
            txtfechaingreso.TabIndex = 15;
            // 
            // txtdescripcion
            // 
            txtdescripcion.Location = new Point(258, 349);
            txtdescripcion.Name = "txtdescripcion";
            txtdescripcion.Size = new Size(326, 23);
            txtdescripcion.TabIndex = 16;
            // 
            // btnguardarrepuesto
            // 
            btnguardarrepuesto.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnguardarrepuesto.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnguardarrepuesto.BackColor = SystemColors.Desktop;
            btnguardarrepuesto.BackgroundImageLayout = ImageLayout.Zoom;
            btnguardarrepuesto.FlatStyle = FlatStyle.Popup;
            btnguardarrepuesto.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnguardarrepuesto.ForeColor = SystemColors.ButtonHighlight;
            btnguardarrepuesto.ImageAlign = ContentAlignment.BottomCenter;
            btnguardarrepuesto.Location = new Point(371, 415);
            btnguardarrepuesto.Name = "btnguardarrepuesto";
            btnguardarrepuesto.Size = new Size(100, 23);
            btnguardarrepuesto.TabIndex = 17;
            btnguardarrepuesto.Text = "GUARDAR";
            btnguardarrepuesto.TextImageRelation = TextImageRelation.TextAboveImage;
            btnguardarrepuesto.UseVisualStyleBackColor = false;
            // 
            // btneliminarrepuesto
            // 
            btneliminarrepuesto.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btneliminarrepuesto.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btneliminarrepuesto.BackColor = SystemColors.Desktop;
            btneliminarrepuesto.BackgroundImageLayout = ImageLayout.Zoom;
            btneliminarrepuesto.FlatStyle = FlatStyle.Popup;
            btneliminarrepuesto.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btneliminarrepuesto.ForeColor = SystemColors.ButtonHighlight;
            btneliminarrepuesto.ImageAlign = ContentAlignment.BottomCenter;
            btneliminarrepuesto.Location = new Point(204, 415);
            btneliminarrepuesto.Name = "btneliminarrepuesto";
            btneliminarrepuesto.Size = new Size(100, 23);
            btneliminarrepuesto.TabIndex = 18;
            btneliminarrepuesto.Text = "ELIMINAR";
            btneliminarrepuesto.TextImageRelation = TextImageRelation.TextAboveImage;
            btneliminarrepuesto.UseVisualStyleBackColor = false;
            // 
            // btnbuscarrepuesto
            // 
            btnbuscarrepuesto.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnbuscarrepuesto.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnbuscarrepuesto.BackColor = SystemColors.Desktop;
            btnbuscarrepuesto.BackgroundImageLayout = ImageLayout.Zoom;
            btnbuscarrepuesto.FlatStyle = FlatStyle.Popup;
            btnbuscarrepuesto.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnbuscarrepuesto.ForeColor = SystemColors.ButtonHighlight;
            btnbuscarrepuesto.ImageAlign = ContentAlignment.BottomCenter;
            btnbuscarrepuesto.Location = new Point(542, 415);
            btnbuscarrepuesto.Name = "btnbuscarrepuesto";
            btnbuscarrepuesto.Size = new Size(100, 23);
            btnbuscarrepuesto.TabIndex = 19;
            btnbuscarrepuesto.Text = "BUSCAR";
            btnbuscarrepuesto.TextImageRelation = TextImageRelation.TextAboveImage;
            btnbuscarrepuesto.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(695, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(103, 129);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(17, 37);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(86, 82);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 41;
            pictureBox3.TabStop = false;
            // 
            // Frmrepuesto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Maroon;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox1);
            Controls.Add(btnbuscarrepuesto);
            Controls.Add(btneliminarrepuesto);
            Controls.Add(btnguardarrepuesto);
            Controls.Add(txtdescripcion);
            Controls.Add(txtfechaingreso);
            Controls.Add(txtmodelo);
            Controls.Add(txtcantidad);
            Controls.Add(txtproveedor);
            Controls.Add(txtprecio);
            Controls.Add(txtidrepuesto);
            Controls.Add(txtnombrerepuesto);
            Controls.Add(lblmarca);
            Controls.Add(lblfechaingreso);
            Controls.Add(lblproveedor);
            Controls.Add(lblcantidad);
            Controls.Add(lbldescripcion);
            Controls.Add(lblprecio);
            Controls.Add(lblnombre);
            Controls.Add(lblid);
            Controls.Add(lbltitulo);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Frmrepuesto";
            Text = "Repuesto";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltitulo;
        private Label lblid;
        private Label lblnombre;
        private Label lblprecio;
        private Label lbldescripcion;
        private Label lblcantidad;
        private Label lblproveedor;
        private Label lblfechaingreso;
        private Label lblmarca;
        private TextBox txtnombrerepuesto;
        private TextBox txtidrepuesto;
        private TextBox txtprecio;
        private TextBox txtproveedor;
        private TextBox txtcantidad;
        private TextBox txtmodelo;
        private TextBox txtfechaingreso;
        private TextBox txtdescripcion;
        private Button btnguardarrepuesto;
        private Button btneliminarrepuesto;
        private Button btnbuscarrepuesto;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
    }
}
