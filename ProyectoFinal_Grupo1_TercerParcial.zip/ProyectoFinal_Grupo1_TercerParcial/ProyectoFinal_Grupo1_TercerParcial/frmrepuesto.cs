namespace ProyectoFinal_Grupo1_TercerParcial
{
    public partial class Frmrepuesto : Form
    {
        public Frmrepuesto()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lbltitulo_Click(object sender, EventArgs e)
        {

        }
    }
}
