﻿namespace ProyectoFinal_Grupo1_TercerParcial
{
    partial class Frmordenrepracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmordenrepracion));
            lbltitulo = new Label();
            lblmecanico = new Label();
            txtmecanico = new TextBox();
            lblnumeroorden = new Label();
            txtnumeroorden = new TextBox();
            txtfechaemicion = new TextBox();
            textplaca = new TextBox();
            lblfechaemicion = new Label();
            lblplaca = new Label();
            lbldiagnostico = new Label();
            txtdiagnostico = new TextBox();
            lblrepuesto = new Label();
            txtrepuesto = new TextBox();
            label1 = new Label();
            txtfirmacliente = new TextBox();
            btneliminar = new Button();
            btnguardar = new Button();
            btnbuscar = new Button();
            lbltrabajorealizar = new Label();
            txttrabajorealizar = new TextBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // lbltitulo
            // 
            lbltitulo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lbltitulo.AutoSize = true;
            lbltitulo.BackColor = Color.Black;
            lbltitulo.BorderStyle = BorderStyle.Fixed3D;
            lbltitulo.Font = new Font("Britannic Bold", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltitulo.ForeColor = SystemColors.ButtonHighlight;
            lbltitulo.Location = new Point(12, 9);
            lbltitulo.Name = "lbltitulo";
            lbltitulo.Size = new Size(180, 23);
            lbltitulo.TabIndex = 2;
            lbltitulo.Text = "ORDEN REPARACION";
            lbltitulo.TextAlign = ContentAlignment.MiddleCenter;
            lbltitulo.Click += lbltitulo_Click;
            // 
            // lblmecanico
            // 
            lblmecanico.AutoSize = true;
            lblmecanico.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblmecanico.Location = new Point(196, 80);
            lblmecanico.Name = "lblmecanico";
            lblmecanico.Size = new Size(84, 15);
            lblmecanico.TabIndex = 26;
            lblmecanico.Text = "MECANICO:";
            // 
            // txtmecanico
            // 
            txtmecanico.Location = new Point(297, 72);
            txtmecanico.Name = "txtmecanico";
            txtmecanico.Size = new Size(326, 23);
            txtmecanico.TabIndex = 27;
            // 
            // lblnumeroorden
            // 
            lblnumeroorden.AutoSize = true;
            lblnumeroorden.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblnumeroorden.Location = new Point(32, 126);
            lblnumeroorden.Name = "lblnumeroorden";
            lblnumeroorden.Size = new Size(143, 15);
            lblnumeroorden.TabIndex = 28;
            lblnumeroorden.Text = "NUMERO DE ORDEN:";
            // 
            // txtnumeroorden
            // 
            txtnumeroorden.Location = new Point(181, 121);
            txtnumeroorden.Name = "txtnumeroorden";
            txtnumeroorden.Size = new Size(165, 23);
            txtnumeroorden.TabIndex = 29;
            // 
            // txtfechaemicion
            // 
            txtfechaemicion.Location = new Point(577, 119);
            txtfechaemicion.Name = "txtfechaemicion";
            txtfechaemicion.Size = new Size(165, 23);
            txtfechaemicion.TabIndex = 30;
            // 
            // textplaca
            // 
            textplaca.Location = new Point(377, 181);
            textplaca.Name = "textplaca";
            textplaca.Size = new Size(165, 23);
            textplaca.TabIndex = 32;
            // 
            // lblfechaemicion
            // 
            lblfechaemicion.AutoSize = true;
            lblfechaemicion.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblfechaemicion.Location = new Point(433, 123);
            lblfechaemicion.Name = "lblfechaemicion";
            lblfechaemicion.Size = new Size(118, 15);
            lblfechaemicion.TabIndex = 34;
            lblfechaemicion.Text = "FECHA EMICION:";
            // 
            // lblplaca
            // 
            lblplaca.AutoSize = true;
            lblplaca.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblplaca.Location = new Point(315, 184);
            lblplaca.Name = "lblplaca";
            lblplaca.Size = new Size(56, 15);
            lblplaca.TabIndex = 38;
            lblplaca.Text = "PLACA:";
            // 
            // lbldiagnostico
            // 
            lbldiagnostico.AutoSize = true;
            lbldiagnostico.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbldiagnostico.Location = new Point(175, 241);
            lbldiagnostico.Name = "lbldiagnostico";
            lbldiagnostico.Size = new Size(105, 15);
            lbldiagnostico.TabIndex = 39;
            lbldiagnostico.Text = "DIAGNOSTICO:";
            // 
            // txtdiagnostico
            // 
            txtdiagnostico.Location = new Point(297, 241);
            txtdiagnostico.Name = "txtdiagnostico";
            txtdiagnostico.Size = new Size(326, 23);
            txtdiagnostico.TabIndex = 40;
            // 
            // lblrepuesto
            // 
            lblrepuesto.AutoSize = true;
            lblrepuesto.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblrepuesto.Location = new Point(196, 324);
            lblrepuesto.Name = "lblrepuesto";
            lblrepuesto.Size = new Size(84, 15);
            lblrepuesto.TabIndex = 41;
            lblrepuesto.Text = "REPUESTO:";
            // 
            // txtrepuesto
            // 
            txtrepuesto.Location = new Point(297, 316);
            txtrepuesto.Name = "txtrepuesto";
            txtrepuesto.Size = new Size(326, 23);
            txtrepuesto.TabIndex = 42;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(171, 362);
            label1.Name = "label1";
            label1.Size = new Size(113, 15);
            label1.TabIndex = 43;
            label1.Text = "FIRMA CLIENTE:";
            // 
            // txtfirmacliente
            // 
            txtfirmacliente.Location = new Point(297, 359);
            txtfirmacliente.Name = "txtfirmacliente";
            txtfirmacliente.Size = new Size(326, 23);
            txtfirmacliente.TabIndex = 44;
            // 
            // btneliminar
            // 
            btneliminar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btneliminar.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btneliminar.BackColor = Color.Black;
            btneliminar.BackgroundImageLayout = ImageLayout.Zoom;
            btneliminar.FlatStyle = FlatStyle.Popup;
            btneliminar.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btneliminar.ForeColor = Color.White;
            btneliminar.ImageAlign = ContentAlignment.BottomCenter;
            btneliminar.Location = new Point(126, 415);
            btneliminar.Name = "btneliminar";
            btneliminar.Size = new Size(100, 23);
            btneliminar.TabIndex = 45;
            btneliminar.Text = "ELIMINAR";
            btneliminar.TextImageRelation = TextImageRelation.TextAboveImage;
            btneliminar.UseVisualStyleBackColor = false;
            // 
            // btnguardar
            // 
            btnguardar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnguardar.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnguardar.BackColor = Color.Black;
            btnguardar.BackgroundImageLayout = ImageLayout.Zoom;
            btnguardar.FlatStyle = FlatStyle.Popup;
            btnguardar.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnguardar.ForeColor = Color.White;
            btnguardar.ImageAlign = ContentAlignment.BottomCenter;
            btnguardar.Location = new Point(339, 415);
            btnguardar.Name = "btnguardar";
            btnguardar.Size = new Size(100, 23);
            btnguardar.TabIndex = 46;
            btnguardar.Text = "GUARDAR";
            btnguardar.TextImageRelation = TextImageRelation.TextAboveImage;
            btnguardar.UseVisualStyleBackColor = false;
            // 
            // btnbuscar
            // 
            btnbuscar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnbuscar.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnbuscar.BackColor = Color.Black;
            btnbuscar.BackgroundImageLayout = ImageLayout.Zoom;
            btnbuscar.FlatStyle = FlatStyle.Popup;
            btnbuscar.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnbuscar.ForeColor = Color.White;
            btnbuscar.ImageAlign = ContentAlignment.BottomCenter;
            btnbuscar.Location = new Point(542, 415);
            btnbuscar.Name = "btnbuscar";
            btnbuscar.Size = new Size(100, 23);
            btnbuscar.TabIndex = 47;
            btnbuscar.Text = "BUSCAR";
            btnbuscar.TextImageRelation = TextImageRelation.TextAboveImage;
            btnbuscar.UseVisualStyleBackColor = false;
            // 
            // lbltrabajorealizar
            // 
            lbltrabajorealizar.AutoSize = true;
            lbltrabajorealizar.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltrabajorealizar.Location = new Point(128, 287);
            lbltrabajorealizar.Name = "lbltrabajorealizar";
            lbltrabajorealizar.Size = new Size(152, 15);
            lbltrabajorealizar.TabIndex = 48;
            lbltrabajorealizar.Text = "TRABAJO A REALIZAR:";
            // 
            // txttrabajorealizar
            // 
            txttrabajorealizar.Location = new Point(297, 279);
            txttrabajorealizar.Name = "txttrabajorealizar";
            txttrabajorealizar.Size = new Size(326, 23);
            txttrabajorealizar.TabIndex = 49;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(673, 356);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(124, 91);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 50;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(52, 35);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(86, 82);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 51;
            pictureBox2.TabStop = false;
            // 
            // Frmordenrepracion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Maroon;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(txttrabajorealizar);
            Controls.Add(lbltrabajorealizar);
            Controls.Add(btnbuscar);
            Controls.Add(btnguardar);
            Controls.Add(btneliminar);
            Controls.Add(txtfirmacliente);
            Controls.Add(label1);
            Controls.Add(txtrepuesto);
            Controls.Add(lblrepuesto);
            Controls.Add(txtdiagnostico);
            Controls.Add(lbldiagnostico);
            Controls.Add(lblplaca);
            Controls.Add(lblfechaemicion);
            Controls.Add(textplaca);
            Controls.Add(txtfechaemicion);
            Controls.Add(txtnumeroorden);
            Controls.Add(lblnumeroorden);
            Controls.Add(txtmecanico);
            Controls.Add(lblmecanico);
            Controls.Add(lbltitulo);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Frmordenrepracion";
            Text = "Orden Reparacion";
            Load += Frmordenrepracion_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltitulo;
        private Label lblmecanico;
        private TextBox txtmecanico;
        private Label lblnumeroorden;
        private TextBox txtnumeroorden;
        private TextBox txtfechaemicion;
        private TextBox textplaca;
        private Label lblfechaemicion;
        private Label lblplaca;
        private Label lbldiagnostico;
        private TextBox txtdiagnostico;
        private Label lblrepuesto;
        private TextBox txtrepuesto;
        private Label label1;
        private TextBox txtfirmacliente;
        private Button btneliminar;
        private Button btnguardar;
        private Button btnbuscar;
        private Label lbltrabajorealizar;
        private TextBox txttrabajorealizar;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}