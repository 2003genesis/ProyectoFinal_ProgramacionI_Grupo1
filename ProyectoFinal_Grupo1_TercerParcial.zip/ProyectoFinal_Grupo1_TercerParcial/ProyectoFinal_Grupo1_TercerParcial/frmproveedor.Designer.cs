﻿namespace ProyectoFinal_Grupo1_TercerParcial
{
    partial class frmproveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmproveedor));
            lbltitulo = new Label();
            lblnombreproveedor = new Label();
            txtnombreproveedor = new TextBox();
            txtservicioofrece = new TextBox();
            lbltelefonoproveedor = new Label();
            lblcorreoproveedor = new Label();
            lbldireccionproveedor = new Label();
            lblservicioofrece = new Label();
            lblrepuesto = new Label();
            lblpago = new Label();
            lblfirmaproveedor = new Label();
            txttelefonoproveedor = new TextBox();
            txtcorreoproveedor = new TextBox();
            txtdireccion = new TextBox();
            txtrepuesto = new TextBox();
            txtpago = new TextBox();
            txtfirmaproveedor = new TextBox();
            btnbuscarproveedor = new Button();
            btnguardarproveedor = new Button();
            btneliminarproveedor = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lbltitulo
            // 
            lbltitulo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lbltitulo.AutoSize = true;
            lbltitulo.BackColor = Color.Black;
            lbltitulo.BorderStyle = BorderStyle.Fixed3D;
            lbltitulo.Font = new Font("Britannic Bold", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltitulo.ForeColor = SystemColors.ButtonHighlight;
            lbltitulo.Location = new Point(12, 9);
            lbltitulo.Name = "lbltitulo";
            lbltitulo.Size = new Size(113, 23);
            lbltitulo.TabIndex = 3;
            lbltitulo.Text = "PROVEEDOR";
            lbltitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblnombreproveedor
            // 
            lblnombreproveedor.AutoSize = true;
            lblnombreproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblnombreproveedor.Location = new Point(140, 73);
            lblnombreproveedor.Name = "lblnombreproveedor";
            lblnombreproveedor.Size = new Size(156, 15);
            lblnombreproveedor.TabIndex = 18;
            lblnombreproveedor.Text = "NOMBRE PROVEEDOR:";
            // 
            // txtnombreproveedor
            // 
            txtnombreproveedor.Location = new Point(302, 70);
            txtnombreproveedor.Name = "txtnombreproveedor";
            txtnombreproveedor.Size = new Size(326, 23);
            txtnombreproveedor.TabIndex = 19;
            // 
            // txtservicioofrece
            // 
            txtservicioofrece.Location = new Point(302, 126);
            txtservicioofrece.Name = "txtservicioofrece";
            txtservicioofrece.Size = new Size(326, 23);
            txtservicioofrece.TabIndex = 21;
            // 
            // lbltelefonoproveedor
            // 
            lbltelefonoproveedor.AutoSize = true;
            lbltelefonoproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbltelefonoproveedor.Location = new Point(12, 189);
            lbltelefonoproveedor.Name = "lbltelefonoproveedor";
            lbltelefonoproveedor.Size = new Size(170, 15);
            lbltelefonoproveedor.TabIndex = 22;
            lbltelefonoproveedor.Text = "TELEFONO PROVEEDOR:";
            // 
            // lblcorreoproveedor
            // 
            lblcorreoproveedor.AutoSize = true;
            lblcorreoproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblcorreoproveedor.Location = new Point(399, 186);
            lblcorreoproveedor.Name = "lblcorreoproveedor";
            lblcorreoproveedor.Size = new Size(155, 15);
            lblcorreoproveedor.TabIndex = 23;
            lblcorreoproveedor.Text = "CORREO PROVEEDOR:";
            // 
            // lbldireccionproveedor
            // 
            lbldireccionproveedor.AutoSize = true;
            lbldireccionproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbldireccionproveedor.Location = new Point(95, 232);
            lbldireccionproveedor.Name = "lbldireccionproveedor";
            lbldireccionproveedor.Size = new Size(87, 15);
            lbldireccionproveedor.TabIndex = 24;
            lbldireccionproveedor.Text = "DIRECCION:";
            // 
            // lblservicioofrece
            // 
            lblservicioofrece.AutoSize = true;
            lblservicioofrece.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblservicioofrece.Location = new Point(131, 126);
            lblservicioofrece.Name = "lblservicioofrece";
            lblservicioofrece.Size = new Size(165, 15);
            lblservicioofrece.TabIndex = 25;
            lblservicioofrece.Text = "SERVICIO QUE OFRECE:";
            // 
            // lblrepuesto
            // 
            lblrepuesto.AutoSize = true;
            lblrepuesto.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblrepuesto.Location = new Point(470, 245);
            lblrepuesto.Name = "lblrepuesto";
            lblrepuesto.Size = new Size(84, 15);
            lblrepuesto.TabIndex = 26;
            lblrepuesto.Text = "REPUESTO:";
            // 
            // lblpago
            // 
            lblpago.AutoSize = true;
            lblpago.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblpago.Location = new Point(133, 300);
            lblpago.Name = "lblpago";
            lblpago.Size = new Size(49, 15);
            lblpago.TabIndex = 27;
            lblpago.Text = "PAGO:";
            // 
            // lblfirmaproveedor
            // 
            lblfirmaproveedor.AutoSize = true;
            lblfirmaproveedor.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblfirmaproveedor.Location = new Point(419, 310);
            lblfirmaproveedor.Name = "lblfirmaproveedor";
            lblfirmaproveedor.Size = new Size(135, 15);
            lblfirmaproveedor.TabIndex = 28;
            lblfirmaproveedor.Text = "FIRMA PROVEEDOR";
            // 
            // txttelefonoproveedor
            // 
            txttelefonoproveedor.Location = new Point(204, 186);
            txttelefonoproveedor.Name = "txttelefonoproveedor";
            txttelefonoproveedor.Size = new Size(165, 23);
            txttelefonoproveedor.TabIndex = 29;
            // 
            // txtcorreoproveedor
            // 
            txtcorreoproveedor.Location = new Point(572, 186);
            txtcorreoproveedor.Name = "txtcorreoproveedor";
            txtcorreoproveedor.Size = new Size(165, 23);
            txtcorreoproveedor.TabIndex = 30;
            // 
            // txtdireccion
            // 
            txtdireccion.Location = new Point(204, 232);
            txtdireccion.Name = "txtdireccion";
            txtdireccion.Size = new Size(165, 23);
            txtdireccion.TabIndex = 31;
            // 
            // txtrepuesto
            // 
            txtrepuesto.Location = new Point(572, 242);
            txtrepuesto.Name = "txtrepuesto";
            txtrepuesto.Size = new Size(165, 23);
            txtrepuesto.TabIndex = 32;
            // 
            // txtpago
            // 
            txtpago.Location = new Point(204, 297);
            txtpago.Name = "txtpago";
            txtpago.Size = new Size(165, 23);
            txtpago.TabIndex = 33;
            // 
            // txtfirmaproveedor
            // 
            txtfirmaproveedor.Location = new Point(572, 310);
            txtfirmaproveedor.Name = "txtfirmaproveedor";
            txtfirmaproveedor.Size = new Size(165, 23);
            txtfirmaproveedor.TabIndex = 34;
            // 
            // btnbuscarproveedor
            // 
            btnbuscarproveedor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnbuscarproveedor.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnbuscarproveedor.BackColor = Color.Black;
            btnbuscarproveedor.BackgroundImageLayout = ImageLayout.Zoom;
            btnbuscarproveedor.FlatStyle = FlatStyle.Popup;
            btnbuscarproveedor.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnbuscarproveedor.ForeColor = Color.White;
            btnbuscarproveedor.ImageAlign = ContentAlignment.BottomCenter;
            btnbuscarproveedor.Location = new Point(554, 389);
            btnbuscarproveedor.Name = "btnbuscarproveedor";
            btnbuscarproveedor.Size = new Size(100, 23);
            btnbuscarproveedor.TabIndex = 37;
            btnbuscarproveedor.Text = "BUSCAR";
            btnbuscarproveedor.TextImageRelation = TextImageRelation.TextAboveImage;
            btnbuscarproveedor.UseVisualStyleBackColor = false;
            // 
            // btnguardarproveedor
            // 
            btnguardarproveedor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnguardarproveedor.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnguardarproveedor.BackColor = Color.Black;
            btnguardarproveedor.BackgroundImageLayout = ImageLayout.Zoom;
            btnguardarproveedor.FlatStyle = FlatStyle.Popup;
            btnguardarproveedor.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnguardarproveedor.ForeColor = Color.White;
            btnguardarproveedor.ImageAlign = ContentAlignment.BottomCenter;
            btnguardarproveedor.Location = new Point(372, 389);
            btnguardarproveedor.Name = "btnguardarproveedor";
            btnguardarproveedor.Size = new Size(100, 23);
            btnguardarproveedor.TabIndex = 36;
            btnguardarproveedor.Text = "GUARDAR";
            btnguardarproveedor.TextImageRelation = TextImageRelation.TextAboveImage;
            btnguardarproveedor.UseVisualStyleBackColor = false;
            // 
            // btneliminarproveedor
            // 
            btneliminarproveedor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btneliminarproveedor.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btneliminarproveedor.BackColor = Color.Black;
            btneliminarproveedor.BackgroundImageLayout = ImageLayout.Zoom;
            btneliminarproveedor.FlatStyle = FlatStyle.Popup;
            btneliminarproveedor.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btneliminarproveedor.ForeColor = Color.White;
            btneliminarproveedor.ImageAlign = ContentAlignment.BottomCenter;
            btneliminarproveedor.Location = new Point(158, 389);
            btneliminarproveedor.Name = "btneliminarproveedor";
            btneliminarproveedor.Size = new Size(100, 23);
            btneliminarproveedor.TabIndex = 35;
            btneliminarproveedor.Text = "ELIMINAR";
            btneliminarproveedor.TextImageRelation = TextImageRelation.TextAboveImage;
            btneliminarproveedor.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(25, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(86, 82);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 40;
            pictureBox1.TabStop = false;
            // 
            // frmproveedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Maroon;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(btnbuscarproveedor);
            Controls.Add(btnguardarproveedor);
            Controls.Add(btneliminarproveedor);
            Controls.Add(txtfirmaproveedor);
            Controls.Add(txtpago);
            Controls.Add(txtrepuesto);
            Controls.Add(txtdireccion);
            Controls.Add(txtcorreoproveedor);
            Controls.Add(txttelefonoproveedor);
            Controls.Add(lblfirmaproveedor);
            Controls.Add(lblpago);
            Controls.Add(lblrepuesto);
            Controls.Add(lblservicioofrece);
            Controls.Add(lbldireccionproveedor);
            Controls.Add(lblcorreoproveedor);
            Controls.Add(lbltelefonoproveedor);
            Controls.Add(txtservicioofrece);
            Controls.Add(txtnombreproveedor);
            Controls.Add(lblnombreproveedor);
            Controls.Add(lbltitulo);
            Name = "frmproveedor";
            Text = "Proveedor";
            Load += frmproveedor_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltitulo;
        private Label lblnombreproveedor;
        private TextBox txtnombreproveedor;
        private TextBox txtservicioofrece;
        private Label lbltelefonoproveedor;
        private Label lblcorreoproveedor;
        private Label lbldireccionproveedor;
        private Label lblservicioofrece;
        private Label lblrepuesto;
        private Label lblpago;
        private Label lblfirmaproveedor;
        private TextBox txttelefonoproveedor;
        private TextBox txtcorreoproveedor;
        private TextBox txtdireccion;
        private TextBox txtrepuesto;
        private TextBox txtpago;
        private TextBox txtfirmaproveedor;
        private Button btnbuscarproveedor;
        private Button btnguardarproveedor;
        private Button btneliminarproveedor;
        private PictureBox pictureBox1;
    }
}