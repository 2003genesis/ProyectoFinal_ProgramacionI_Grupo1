﻿namespace ProyectoFinal_Grupo1_TercerParcial
{
    partial class frmmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmenu));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            btncliente = new Button();
            btnempleado = new Button();
            btncita = new Button();
            btbfactura = new Button();
            btninventario = new Button();
            btnmecanico = new Button();
            btnordenreparacion = new Button();
            btnpago = new Button();
            btnproveedor = new Button();
            btnrepuesto = new Button();
            btnservicio = new Button();
            btnvehiculo = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(389, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(217, 148);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(605, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(196, 147);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(390, 144);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(217, 176);
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(607, 147);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(194, 173);
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(390, 311);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(216, 140);
            pictureBox5.TabIndex = 4;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(585, 311);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(216, 140);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gill Sans Ultra Bold", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Maroon;
            label1.Location = new Point(31, 9);
            label1.Name = "label1";
            label1.Size = new Size(190, 39);
            label1.TabIndex = 6;
            label1.Text = "AUTO CAR";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gill Sans Ultra Bold", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(150, 57);
            label2.Name = "label2";
            label2.Size = new Size(192, 30);
            label2.TabIndex = 7;
            label2.Text = "REPAIR SHOP";
            // 
            // btncliente
            // 
            btncliente.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btncliente.BackColor = Color.Maroon;
            btncliente.FlatStyle = FlatStyle.Popup;
            btncliente.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btncliente.ForeColor = SystemColors.ActiveBorder;
            btncliente.ImageAlign = ContentAlignment.TopCenter;
            btncliente.Location = new Point(22, 124);
            btncliente.Name = "btncliente";
            btncliente.Size = new Size(102, 23);
            btncliente.TabIndex = 8;
            btncliente.Text = "CLIENTE";
            btncliente.UseVisualStyleBackColor = false;
            // 
            // btnempleado
            // 
            btnempleado.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnempleado.BackColor = Color.Maroon;
            btnempleado.FlatStyle = FlatStyle.Popup;
            btnempleado.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnempleado.ForeColor = SystemColors.ActiveBorder;
            btnempleado.ImageAlign = ContentAlignment.TopCenter;
            btnempleado.Location = new Point(22, 175);
            btnempleado.Name = "btnempleado";
            btnempleado.Size = new Size(102, 23);
            btnempleado.TabIndex = 9;
            btnempleado.Text = "EMPLEADO";
            btnempleado.UseVisualStyleBackColor = false;
            // 
            // btncita
            // 
            btncita.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btncita.BackColor = Color.Maroon;
            btncita.FlatStyle = FlatStyle.Popup;
            btncita.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btncita.ForeColor = SystemColors.ActiveBorder;
            btncita.ImageAlign = ContentAlignment.TopCenter;
            btncita.Location = new Point(22, 224);
            btncita.Name = "btncita";
            btncita.Size = new Size(102, 23);
            btncita.TabIndex = 10;
            btncita.Text = "CITA";
            btncita.UseVisualStyleBackColor = false;
            // 
            // btbfactura
            // 
            btbfactura.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btbfactura.BackColor = Color.Maroon;
            btbfactura.FlatStyle = FlatStyle.Popup;
            btbfactura.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btbfactura.ForeColor = SystemColors.ActiveBorder;
            btbfactura.ImageAlign = ContentAlignment.TopCenter;
            btbfactura.Location = new Point(22, 271);
            btbfactura.Name = "btbfactura";
            btbfactura.Size = new Size(102, 24);
            btbfactura.TabIndex = 11;
            btbfactura.Text = "FACTURA";
            btbfactura.UseVisualStyleBackColor = false;
            // 
            // btninventario
            // 
            btninventario.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btninventario.BackColor = Color.Maroon;
            btninventario.FlatStyle = FlatStyle.Popup;
            btninventario.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btninventario.ForeColor = SystemColors.ActiveBorder;
            btninventario.ImageAlign = ContentAlignment.TopCenter;
            btninventario.Location = new Point(211, 311);
            btninventario.Name = "btninventario";
            btninventario.Size = new Size(112, 25);
            btninventario.TabIndex = 12;
            btninventario.Text = "INVENTARIO";
            btninventario.UseVisualStyleBackColor = false;
            // 
            // btnmecanico
            // 
            btnmecanico.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnmecanico.BackColor = Color.Maroon;
            btnmecanico.FlatStyle = FlatStyle.Popup;
            btnmecanico.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnmecanico.ForeColor = SystemColors.ActiveBorder;
            btnmecanico.ImageAlign = ContentAlignment.TopCenter;
            btnmecanico.Location = new Point(22, 370);
            btnmecanico.Name = "btnmecanico";
            btnmecanico.Size = new Size(102, 21);
            btnmecanico.TabIndex = 13;
            btnmecanico.Text = "MECANICO";
            btnmecanico.UseVisualStyleBackColor = false;
            // 
            // btnordenreparacion
            // 
            btnordenreparacion.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnordenreparacion.BackColor = Color.Maroon;
            btnordenreparacion.FlatStyle = FlatStyle.Popup;
            btnordenreparacion.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnordenreparacion.ForeColor = SystemColors.ActiveBorder;
            btnordenreparacion.ImageAlign = ContentAlignment.TopCenter;
            btnordenreparacion.Location = new Point(211, 354);
            btnordenreparacion.Name = "btnordenreparacion";
            btnordenreparacion.Size = new Size(112, 48);
            btnordenreparacion.TabIndex = 14;
            btnordenreparacion.Text = "ORDEN REPARACION";
            btnordenreparacion.UseVisualStyleBackColor = false;
            // 
            // btnpago
            // 
            btnpago.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnpago.BackColor = Color.Maroon;
            btnpago.FlatStyle = FlatStyle.Popup;
            btnpago.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnpago.ForeColor = SystemColors.ActiveBorder;
            btnpago.ImageAlign = ContentAlignment.TopCenter;
            btnpago.Location = new Point(211, 124);
            btnpago.Name = "btnpago";
            btnpago.Size = new Size(112, 23);
            btnpago.TabIndex = 15;
            btnpago.Text = "PAGO";
            btnpago.UseVisualStyleBackColor = false;
            btnpago.Click += btnpago_Click;
            // 
            // btnproveedor
            // 
            btnproveedor.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnproveedor.BackColor = Color.Maroon;
            btnproveedor.FlatStyle = FlatStyle.Popup;
            btnproveedor.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnproveedor.ForeColor = SystemColors.ActiveBorder;
            btnproveedor.ImageAlign = ContentAlignment.TopCenter;
            btnproveedor.Location = new Point(211, 175);
            btnproveedor.Name = "btnproveedor";
            btnproveedor.Size = new Size(112, 23);
            btnproveedor.TabIndex = 16;
            btnproveedor.Text = "PROVEEDOR";
            btnproveedor.UseVisualStyleBackColor = false;
            // 
            // btnrepuesto
            // 
            btnrepuesto.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnrepuesto.BackColor = Color.Maroon;
            btnrepuesto.FlatStyle = FlatStyle.Popup;
            btnrepuesto.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnrepuesto.ForeColor = SystemColors.ActiveBorder;
            btnrepuesto.ImageAlign = ContentAlignment.TopCenter;
            btnrepuesto.Location = new Point(211, 224);
            btnrepuesto.Name = "btnrepuesto";
            btnrepuesto.Size = new Size(112, 23);
            btnrepuesto.TabIndex = 17;
            btnrepuesto.Text = "REPUESTO";
            btnrepuesto.UseVisualStyleBackColor = false;
            // 
            // btnservicio
            // 
            btnservicio.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnservicio.BackColor = Color.Maroon;
            btnservicio.FlatStyle = FlatStyle.Popup;
            btnservicio.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnservicio.ForeColor = SystemColors.ActiveBorder;
            btnservicio.ImageAlign = ContentAlignment.TopCenter;
            btnservicio.Location = new Point(211, 272);
            btnservicio.Name = "btnservicio";
            btnservicio.Size = new Size(112, 23);
            btnservicio.TabIndex = 18;
            btnservicio.Text = "SERVICIO";
            btnservicio.UseVisualStyleBackColor = false;
            // 
            // btnvehiculo
            // 
            btnvehiculo.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnvehiculo.BackColor = Color.Maroon;
            btnvehiculo.FlatStyle = FlatStyle.Popup;
            btnvehiculo.Font = new Font("Cooper Black", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnvehiculo.ForeColor = SystemColors.ActiveBorder;
            btnvehiculo.ImageAlign = ContentAlignment.TopCenter;
            btnvehiculo.Location = new Point(21, 323);
            btnvehiculo.Name = "btnvehiculo";
            btnvehiculo.Size = new Size(103, 25);
            btnvehiculo.TabIndex = 19;
            btnvehiculo.Text = "VEHICULO";
            btnvehiculo.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Gill Sans Ultra Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Maroon;
            label3.Location = new Point(258, 418);
            label3.Name = "label3";
            label3.Size = new Size(113, 23);
            label3.TabIndex = 20;
            label3.Text = "GRUPO \"1\"";
            // 
            // frmmenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(btnvehiculo);
            Controls.Add(btnservicio);
            Controls.Add(btnrepuesto);
            Controls.Add(btnproveedor);
            Controls.Add(btnpago);
            Controls.Add(btnordenreparacion);
            Controls.Add(btnmecanico);
            Controls.Add(btninventario);
            Controls.Add(btbfactura);
            Controls.Add(btncita);
            Controls.Add(btnempleado);
            Controls.Add(btncliente);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Name = "frmmenu";
            Text = "frmmenu";
            Load += frmmenu_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label1;
        private Label label2;
        private Button btncliente;
        private Button btnempleado;
        private Button btncita;
        private Button btbfactura;
        private Button btninventario;
        private Button btnmecanico;
        private Button btnordenreparacion;
        private Button btnpago;
        private Button btnproveedor;
        private Button btnrepuesto;
        private Button btnservicio;
        private Button btnvehiculo;
        private Label label3;
    }
}