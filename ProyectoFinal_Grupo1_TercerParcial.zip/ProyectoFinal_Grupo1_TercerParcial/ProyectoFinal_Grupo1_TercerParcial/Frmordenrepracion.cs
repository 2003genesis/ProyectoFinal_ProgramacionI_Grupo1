﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal_Grupo1_TercerParcial
{
    public partial class Frmordenrepracion : Form
    {
        public Frmordenrepracion()
        {
            InitializeComponent();
        }

        private void Frmordenrepracion_Load(object sender, EventArgs e)
        {

        }

        private void lbltitulo_Click(object sender, EventArgs e)
        {

        }
    }
}
