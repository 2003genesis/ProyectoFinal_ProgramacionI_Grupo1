﻿namespace ProyectoFinal_Grupo1_TercerParcial
{
    partial class frmservicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmservicio));
            lbltitulo = new Label();
            lblfechaingreso = new Label();
            txtfechaingreso = new TextBox();
            lblnombrecliente = new Label();
            txtnombrecliente = new TextBox();
            lbldescripcionproblema = new Label();
            txtdescripcionproblema = new TextBox();
            lblplaca = new Label();
            txtplaca = new TextBox();
            lblserviciorealizado = new Label();
            txtserviciorealizado = new TextBox();
            lblmecanico = new Label();
            txtmecanico = new TextBox();
            lblcostototal = new Label();
            txtcostototal = new TextBox();
            lblestadoservicio = new Label();
            btneliminarservicio = new Button();
            btnguardarservicio = new Button();
            btnbuscarservicio = new Button();
            listBox1 = new ListBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lbltitulo
            // 
            lbltitulo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lbltitulo.AutoSize = true;
            lbltitulo.BackColor = Color.Black;
            lbltitulo.BorderStyle = BorderStyle.Fixed3D;
            lbltitulo.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltitulo.ForeColor = Color.Lavender;
            lbltitulo.Location = new Point(12, 9);
            lbltitulo.Name = "lbltitulo";
            lbltitulo.Size = new Size(105, 24);
            lbltitulo.TabIndex = 1;
            lbltitulo.Text = "SERVICIO";
            lbltitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblfechaingreso
            // 
            lblfechaingreso.AutoSize = true;
            lblfechaingreso.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblfechaingreso.Location = new Point(45, 188);
            lblfechaingreso.Name = "lblfechaingreso";
            lblfechaingreso.Size = new Size(121, 15);
            lblfechaingreso.TabIndex = 8;
            lblfechaingreso.Text = "FECHA INGRESO:";
            // 
            // txtfechaingreso
            // 
            txtfechaingreso.Location = new Point(182, 185);
            txtfechaingreso.Name = "txtfechaingreso";
            txtfechaingreso.Size = new Size(165, 23);
            txtfechaingreso.TabIndex = 16;
            // 
            // lblnombrecliente
            // 
            lblnombrecliente.AutoSize = true;
            lblnombrecliente.BackColor = Color.Maroon;
            lblnombrecliente.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblnombrecliente.Location = new Point(112, 81);
            lblnombrecliente.Name = "lblnombrecliente";
            lblnombrecliente.Size = new Size(130, 15);
            lblnombrecliente.TabIndex = 17;
            lblnombrecliente.Text = "NOMBRE CLIENTE:";
            // 
            // txtnombrecliente
            // 
            txtnombrecliente.Location = new Point(248, 78);
            txtnombrecliente.Name = "txtnombrecliente";
            txtnombrecliente.Size = new Size(326, 23);
            txtnombrecliente.TabIndex = 18;
            // 
            // lbldescripcionproblema
            // 
            lbldescripcionproblema.AutoSize = true;
            lbldescripcionproblema.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbldescripcionproblema.Location = new Point(139, 260);
            lbldescripcionproblema.Name = "lbldescripcionproblema";
            lbldescripcionproblema.Size = new Size(212, 15);
            lbldescripcionproblema.TabIndex = 19;
            lbldescripcionproblema.Text = "DESCRIPCION DEL PROBLEMA:";
            // 
            // txtdescripcionproblema
            // 
            txtdescripcionproblema.Location = new Point(357, 257);
            txtdescripcionproblema.Name = "txtdescripcionproblema";
            txtdescripcionproblema.Size = new Size(326, 23);
            txtdescripcionproblema.TabIndex = 20;
            // 
            // lblplaca
            // 
            lblplaca.AutoSize = true;
            lblplaca.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblplaca.Location = new Point(400, 185);
            lblplaca.Name = "lblplaca";
            lblplaca.Size = new Size(56, 15);
            lblplaca.TabIndex = 21;
            lblplaca.Text = "PLACA:";
            // 
            // txtplaca
            // 
            txtplaca.Location = new Point(473, 185);
            txtplaca.Name = "txtplaca";
            txtplaca.Size = new Size(165, 23);
            txtplaca.TabIndex = 22;
            // 
            // lblserviciorealizado
            // 
            lblserviciorealizado.AutoSize = true;
            lblserviciorealizado.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblserviciorealizado.Location = new Point(184, 304);
            lblserviciorealizado.Name = "lblserviciorealizado";
            lblserviciorealizado.Size = new Size(163, 15);
            lblserviciorealizado.TabIndex = 23;
            lblserviciorealizado.Text = "SERVICIO REALIZADOS:";
            // 
            // txtserviciorealizado
            // 
            txtserviciorealizado.Location = new Point(357, 301);
            txtserviciorealizado.Name = "txtserviciorealizado";
            txtserviciorealizado.Size = new Size(326, 23);
            txtserviciorealizado.TabIndex = 24;
            // 
            // lblmecanico
            // 
            lblmecanico.AutoSize = true;
            lblmecanico.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblmecanico.Location = new Point(158, 130);
            lblmecanico.Name = "lblmecanico";
            lblmecanico.Size = new Size(84, 15);
            lblmecanico.TabIndex = 25;
            lblmecanico.Text = "MECANICO:";
            // 
            // txtmecanico
            // 
            txtmecanico.Location = new Point(248, 127);
            txtmecanico.Name = "txtmecanico";
            txtmecanico.Size = new Size(326, 23);
            txtmecanico.TabIndex = 26;
            // 
            // lblcostototal
            // 
            lblcostototal.AutoSize = true;
            lblcostototal.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblcostototal.Location = new Point(62, 354);
            lblcostototal.Name = "lblcostototal";
            lblcostototal.Size = new Size(104, 15);
            lblcostototal.TabIndex = 27;
            lblcostototal.Text = "COSTO TOTAL:";
            // 
            // txtcostototal
            // 
            txtcostototal.Location = new Point(186, 351);
            txtcostototal.Name = "txtcostototal";
            txtcostototal.Size = new Size(165, 23);
            txtcostototal.TabIndex = 28;
            // 
            // lblestadoservicio
            // 
            lblestadoservicio.AutoSize = true;
            lblestadoservicio.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblestadoservicio.Location = new Point(618, 23);
            lblestadoservicio.Name = "lblestadoservicio";
            lblestadoservicio.Size = new Size(133, 15);
            lblestadoservicio.TabIndex = 29;
            lblestadoservicio.Text = "ESTADO SERVICIO:";
            // 
            // btneliminarservicio
            // 
            btneliminarservicio.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btneliminarservicio.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btneliminarservicio.BackColor = Color.Black;
            btneliminarservicio.BackgroundImageLayout = ImageLayout.Zoom;
            btneliminarservicio.FlatStyle = FlatStyle.Popup;
            btneliminarservicio.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btneliminarservicio.ForeColor = Color.FromArgb(224, 224, 224);
            btneliminarservicio.ImageAlign = ContentAlignment.BottomCenter;
            btneliminarservicio.Location = new Point(142, 415);
            btneliminarservicio.Name = "btneliminarservicio";
            btneliminarservicio.Size = new Size(100, 23);
            btneliminarservicio.TabIndex = 32;
            btneliminarservicio.Text = "ELIMINAR";
            btneliminarservicio.TextImageRelation = TextImageRelation.TextAboveImage;
            btneliminarservicio.UseVisualStyleBackColor = false;
            // 
            // btnguardarservicio
            // 
            btnguardarservicio.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnguardarservicio.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnguardarservicio.BackColor = Color.Black;
            btnguardarservicio.BackgroundImageLayout = ImageLayout.Zoom;
            btnguardarservicio.FlatStyle = FlatStyle.Popup;
            btnguardarservicio.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnguardarservicio.ForeColor = Color.FromArgb(224, 224, 224);
            btnguardarservicio.ImageAlign = ContentAlignment.BottomCenter;
            btnguardarservicio.Location = new Point(356, 415);
            btnguardarservicio.Margin = new Padding(6, 3, 3, 3);
            btnguardarservicio.Name = "btnguardarservicio";
            btnguardarservicio.Size = new Size(100, 23);
            btnguardarservicio.TabIndex = 33;
            btnguardarservicio.Text = "GUARDAR";
            btnguardarservicio.TextImageRelation = TextImageRelation.TextAboveImage;
            btnguardarservicio.UseVisualStyleBackColor = false;
            // 
            // btnbuscarservicio
            // 
            btnbuscarservicio.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnbuscarservicio.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnbuscarservicio.BackColor = Color.Black;
            btnbuscarservicio.BackgroundImageLayout = ImageLayout.Zoom;
            btnbuscarservicio.FlatStyle = FlatStyle.Popup;
            btnbuscarservicio.Font = new Font("Britannic Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnbuscarservicio.ForeColor = Color.FromArgb(224, 224, 224);
            btnbuscarservicio.ImageAlign = ContentAlignment.BottomCenter;
            btnbuscarservicio.Location = new Point(538, 415);
            btnbuscarservicio.Name = "btnbuscarservicio";
            btnbuscarservicio.Size = new Size(100, 23);
            btnbuscarservicio.TabIndex = 34;
            btnbuscarservicio.Text = "BUSCAR";
            btnbuscarservicio.TextImageRelation = TextImageRelation.TextAboveImage;
            btnbuscarservicio.UseVisualStyleBackColor = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Items.AddRange(new object[] { "PENDIENTE", "TERMINADO" });
            listBox1.Location = new Point(644, 50);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(107, 64);
            listBox1.TabIndex = 35;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(699, 286);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 163);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 37;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(21, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(86, 82);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            // 
            // frmservicio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Maroon;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox2);
            Controls.Add(listBox1);
            Controls.Add(btnbuscarservicio);
            Controls.Add(btnguardarservicio);
            Controls.Add(btneliminarservicio);
            Controls.Add(lblestadoservicio);
            Controls.Add(txtcostototal);
            Controls.Add(lblcostototal);
            Controls.Add(txtmecanico);
            Controls.Add(lblmecanico);
            Controls.Add(txtserviciorealizado);
            Controls.Add(lblserviciorealizado);
            Controls.Add(txtplaca);
            Controls.Add(lblplaca);
            Controls.Add(txtdescripcionproblema);
            Controls.Add(lbldescripcionproblema);
            Controls.Add(txtnombrecliente);
            Controls.Add(lblnombrecliente);
            Controls.Add(txtfechaingreso);
            Controls.Add(lblfechaingreso);
            Controls.Add(lbltitulo);
            Name = "frmservicio";
            Text = "+6";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltitulo;
        private Label lblfechaingreso;
        private TextBox txtfechaingreso;
        private Label lblnombrecliente;
        private TextBox txtnombrecliente;
        private Label lbldescripcionproblema;
        private TextBox txtdescripcionproblema;
        private Label lblplaca;
        private TextBox txtplaca;
        private Label lblserviciorealizado;
        private TextBox txtserviciorealizado;
        private Label lblmecanico;
        private TextBox txtmecanico;
        private Label lblcostototal;
        private TextBox txtcostototal;
        private Label lblestadoservicio;
        private Button btneliminarservicio;
        private Button btnguardarservicio;
        private Button btnbuscarservicio;
        private ListBox listBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
    }
}