﻿namespace vehiculo
{
    partial class frmMecanico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMecanico));
            this.IbIID = new System.Windows.Forms.Label();
            this.IbInombre = new System.Windows.Forms.Label();
            this.IbIapellido = new System.Windows.Forms.Label();
            this.IbIsalario = new System.Windows.Forms.Label();
            this.IbITELEFONO = new System.Windows.Forms.Label();
            this.IbICORREO = new System.Windows.Forms.Label();
            this.IBIESPECIALIDAD = new System.Windows.Forms.Label();
            this.IBIEXPERIENCIA = new System.Windows.Forms.Label();
            this.TXTID = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.TXTapellido = new System.Windows.Forms.TextBox();
            this.txtsalario = new System.Windows.Forms.TextBox();
            this.txtTELEFONO = new System.Windows.Forms.TextBox();
            this.TXTCORREO = new System.Windows.Forms.TextBox();
            this.TXTESPECIALIDAD = new System.Windows.Forms.TextBox();
            this.TXTEXPERIENCIA = new System.Windows.Forms.TextBox();
            this.btnBUSCAR = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNELIMINAR = new System.Windows.Forms.Button();
            this.IBI = new System.Windows.Forms.Label();
            this.BTNMODIFICAR = new System.Windows.Forms.Button();
            this.BTNAGREGAR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // IbIID
            // 
            this.IbIID.AutoSize = true;
            this.IbIID.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbIID.Location = new System.Drawing.Point(258, 51);
            this.IbIID.Name = "IbIID";
            this.IbIID.Size = new System.Drawing.Size(42, 24);
            this.IbIID.TabIndex = 0;
            this.IbIID.Text = "ID :";
            // 
            // IbInombre
            // 
            this.IbInombre.AutoSize = true;
            this.IbInombre.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbInombre.Location = new System.Drawing.Point(205, 118);
            this.IbInombre.Name = "IbInombre";
            this.IbInombre.Size = new System.Drawing.Size(111, 24);
            this.IbInombre.TabIndex = 1;
            this.IbInombre.Text = "NOMBRE :";
            // 
            // IbIapellido
            // 
            this.IbIapellido.AutoSize = true;
            this.IbIapellido.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbIapellido.Location = new System.Drawing.Point(195, 174);
            this.IbIapellido.Name = "IbIapellido";
            this.IbIapellido.Size = new System.Drawing.Size(121, 24);
            this.IbIapellido.TabIndex = 2;
            this.IbIapellido.Text = "APELLIDO :";
            // 
            // IbIsalario
            // 
            this.IbIsalario.AutoSize = true;
            this.IbIsalario.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbIsalario.Location = new System.Drawing.Point(205, 247);
            this.IbIsalario.Name = "IbIsalario";
            this.IbIsalario.Size = new System.Drawing.Size(109, 24);
            this.IbIsalario.TabIndex = 3;
            this.IbIsalario.Text = "SALARIO :";
            // 
            // IbITELEFONO
            // 
            this.IbITELEFONO.AutoSize = true;
            this.IbITELEFONO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbITELEFONO.Location = new System.Drawing.Point(184, 309);
            this.IbITELEFONO.Name = "IbITELEFONO";
            this.IbITELEFONO.Size = new System.Drawing.Size(132, 24);
            this.IbITELEFONO.TabIndex = 4;
            this.IbITELEFONO.Text = "TELEFONO :";
            // 
            // IbICORREO
            // 
            this.IbICORREO.AutoSize = true;
            this.IbICORREO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IbICORREO.Location = new System.Drawing.Point(206, 364);
            this.IbICORREO.Name = "IbICORREO";
            this.IbICORREO.Size = new System.Drawing.Size(110, 24);
            this.IbICORREO.TabIndex = 5;
            this.IbICORREO.Text = "CORREO :";
            // 
            // IBIESPECIALIDAD
            // 
            this.IBIESPECIALIDAD.AutoSize = true;
            this.IBIESPECIALIDAD.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIESPECIALIDAD.Location = new System.Drawing.Point(149, 430);
            this.IBIESPECIALIDAD.Name = "IBIESPECIALIDAD";
            this.IBIESPECIALIDAD.Size = new System.Drawing.Size(165, 24);
            this.IBIESPECIALIDAD.TabIndex = 6;
            this.IBIESPECIALIDAD.Text = "ESPECIALIDAD :";
            // 
            // IBIEXPERIENCIA
            // 
            this.IBIEXPERIENCIA.AutoSize = true;
            this.IBIEXPERIENCIA.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIEXPERIENCIA.Location = new System.Drawing.Point(162, 490);
            this.IBIEXPERIENCIA.Name = "IBIEXPERIENCIA";
            this.IBIEXPERIENCIA.Size = new System.Drawing.Size(152, 24);
            this.IBIEXPERIENCIA.TabIndex = 7;
            this.IBIEXPERIENCIA.Text = "EXPERIENCIA :";
            // 
            // TXTID
            // 
            this.TXTID.Location = new System.Drawing.Point(356, 49);
            this.TXTID.Name = "TXTID";
            this.TXTID.Size = new System.Drawing.Size(223, 26);
            this.TXTID.TabIndex = 9;
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(356, 110);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(223, 26);
            this.txtnombre.TabIndex = 10;
            // 
            // TXTapellido
            // 
            this.TXTapellido.Location = new System.Drawing.Point(356, 172);
            this.TXTapellido.Name = "TXTapellido";
            this.TXTapellido.Size = new System.Drawing.Size(223, 26);
            this.TXTapellido.TabIndex = 11;
            this.TXTapellido.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtsalario
            // 
            this.txtsalario.Location = new System.Drawing.Point(356, 240);
            this.txtsalario.Name = "txtsalario";
            this.txtsalario.Size = new System.Drawing.Size(223, 26);
            this.txtsalario.TabIndex = 12;
            // 
            // txtTELEFONO
            // 
            this.txtTELEFONO.Location = new System.Drawing.Point(356, 307);
            this.txtTELEFONO.Name = "txtTELEFONO";
            this.txtTELEFONO.Size = new System.Drawing.Size(223, 26);
            this.txtTELEFONO.TabIndex = 13;
            // 
            // TXTCORREO
            // 
            this.TXTCORREO.Location = new System.Drawing.Point(356, 364);
            this.TXTCORREO.Name = "TXTCORREO";
            this.TXTCORREO.Size = new System.Drawing.Size(223, 26);
            this.TXTCORREO.TabIndex = 14;
            // 
            // TXTESPECIALIDAD
            // 
            this.TXTESPECIALIDAD.Location = new System.Drawing.Point(356, 428);
            this.TXTESPECIALIDAD.Name = "TXTESPECIALIDAD";
            this.TXTESPECIALIDAD.Size = new System.Drawing.Size(223, 26);
            this.TXTESPECIALIDAD.TabIndex = 15;
            // 
            // TXTEXPERIENCIA
            // 
            this.TXTEXPERIENCIA.Location = new System.Drawing.Point(356, 490);
            this.TXTEXPERIENCIA.Name = "TXTEXPERIENCIA";
            this.TXTEXPERIENCIA.Size = new System.Drawing.Size(223, 26);
            this.TXTEXPERIENCIA.TabIndex = 16;
            // 
            // btnBUSCAR
            // 
            this.btnBUSCAR.BackColor = System.Drawing.Color.Black;
            this.btnBUSCAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBUSCAR.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBUSCAR.Location = new System.Drawing.Point(368, 569);
            this.btnBUSCAR.Name = "btnBUSCAR";
            this.btnBUSCAR.Size = new System.Drawing.Size(211, 47);
            this.btnBUSCAR.TabIndex = 18;
            this.btnBUSCAR.Text = "BUSCAR";
            this.btnBUSCAR.UseVisualStyleBackColor = false;
            this.btnBUSCAR.Click += new System.EventHandler(this.btnRegistrarmecanico_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(618, 90);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(365, 389);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BTNELIMINAR
            // 
            this.BTNELIMINAR.BackColor = System.Drawing.Color.Black;
            this.BTNELIMINAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNELIMINAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNELIMINAR.Location = new System.Drawing.Point(618, 569);
            this.BTNELIMINAR.Name = "BTNELIMINAR";
            this.BTNELIMINAR.Size = new System.Drawing.Size(169, 46);
            this.BTNELIMINAR.TabIndex = 22;
            this.BTNELIMINAR.Text = "ELIMINAR";
            this.BTNELIMINAR.UseVisualStyleBackColor = false;
            // 
            // IBI
            // 
            this.IBI.AutoSize = true;
            this.IBI.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBI.Location = new System.Drawing.Point(243, 10);
            this.IBI.Name = "IBI";
            this.IBI.Size = new System.Drawing.Size(275, 24);
            this.IBI.TabIndex = 23;
            this.IBI.Text = "BIENVENIDOS MECANICOS ";
            // 
            // BTNMODIFICAR
            // 
            this.BTNMODIFICAR.BackColor = System.Drawing.Color.Black;
            this.BTNMODIFICAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNMODIFICAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNMODIFICAR.Location = new System.Drawing.Point(835, 570);
            this.BTNMODIFICAR.Name = "BTNMODIFICAR";
            this.BTNMODIFICAR.Size = new System.Drawing.Size(132, 46);
            this.BTNMODIFICAR.TabIndex = 24;
            this.BTNMODIFICAR.Text = "MODIFICAR";
            this.BTNMODIFICAR.UseVisualStyleBackColor = false;
            // 
            // BTNAGREGAR
            // 
            this.BTNAGREGAR.BackColor = System.Drawing.Color.Black;
            this.BTNAGREGAR.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNAGREGAR.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BTNAGREGAR.Location = new System.Drawing.Point(171, 575);
            this.BTNAGREGAR.Name = "BTNAGREGAR";
            this.BTNAGREGAR.Size = new System.Drawing.Size(155, 40);
            this.BTNAGREGAR.TabIndex = 25;
            this.BTNAGREGAR.Text = "AGREGAR";
            this.BTNAGREGAR.UseVisualStyleBackColor = false;
            // 
            // frmMecanico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(995, 663);
            this.Controls.Add(this.BTNAGREGAR);
            this.Controls.Add(this.BTNMODIFICAR);
            this.Controls.Add(this.IBI);
            this.Controls.Add(this.BTNELIMINAR);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnBUSCAR);
            this.Controls.Add(this.TXTEXPERIENCIA);
            this.Controls.Add(this.TXTESPECIALIDAD);
            this.Controls.Add(this.TXTCORREO);
            this.Controls.Add(this.txtTELEFONO);
            this.Controls.Add(this.txtsalario);
            this.Controls.Add(this.TXTapellido);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.TXTID);
            this.Controls.Add(this.IBIEXPERIENCIA);
            this.Controls.Add(this.IBIESPECIALIDAD);
            this.Controls.Add(this.IbICORREO);
            this.Controls.Add(this.IbITELEFONO);
            this.Controls.Add(this.IbIsalario);
            this.Controls.Add(this.IbIapellido);
            this.Controls.Add(this.IbInombre);
            this.Controls.Add(this.IbIID);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMecanico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mecanico";
            this.Load += new System.EventHandler(this.frmMecanico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label IbIID;
        private System.Windows.Forms.Label IbInombre;
        private System.Windows.Forms.Label IbIapellido;
        private System.Windows.Forms.Label IbIsalario;
        private System.Windows.Forms.Label IbITELEFONO;
        private System.Windows.Forms.Label IbICORREO;
        private System.Windows.Forms.Label IBIESPECIALIDAD;
        private System.Windows.Forms.Label IBIEXPERIENCIA;
        private System.Windows.Forms.TextBox TXTID;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox TXTapellido;
        private System.Windows.Forms.TextBox txtsalario;
        private System.Windows.Forms.TextBox txtTELEFONO;
        private System.Windows.Forms.TextBox TXTCORREO;
        private System.Windows.Forms.TextBox TXTESPECIALIDAD;
        private System.Windows.Forms.TextBox TXTEXPERIENCIA;
        private System.Windows.Forms.Button btnBUSCAR;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNELIMINAR;
        private System.Windows.Forms.Label IBI;
        private System.Windows.Forms.Button BTNMODIFICAR;
        private System.Windows.Forms.Button BTNAGREGAR;
    }
}