﻿namespace vehiculo
{
    partial class FrmEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEmpleado));
            this.lblID = new System.Windows.Forms.Label();
            this.IBINOMBRE = new System.Windows.Forms.Label();
            this.IBIAPELLIDO = new System.Windows.Forms.Label();
            this.IBICARGO = new System.Windows.Forms.Label();
            this.IBISALARIO = new System.Windows.Forms.Label();
            this.IBITELEFONO = new System.Windows.Forms.Label();
            this.IBICORREO = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.TXTNOMBRE = new System.Windows.Forms.TextBox();
            this.TXTAPELLIDO = new System.Windows.Forms.TextBox();
            this.TXTCARGO = new System.Windows.Forms.TextBox();
            this.TXTSALARIO = new System.Windows.Forms.TextBox();
            this.TXTTELEFONO = new System.Windows.Forms.TextBox();
            this.TXTCORREO = new System.Windows.Forms.TextBox();
            this.BTNAGREGAR = new System.Windows.Forms.Button();
            this.IBIEMPLEADOS = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.IBIFECHA = new System.Windows.Forms.Label();
            this.TXTFECHA = new System.Windows.Forms.TextBox();
            this.BTNELIMINAR = new System.Windows.Forms.Button();
            this.BTNBUSCAR = new System.Windows.Forms.Button();
            this.BTNMODIFICAR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(166, 128);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(42, 24);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "ID :";
            this.lblID.Click += new System.EventHandler(this.label1_Click);
            // 
            // IBINOMBRE
            // 
            this.IBINOMBRE.AutoSize = true;
            this.IBINOMBRE.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBINOMBRE.Location = new System.Drawing.Point(97, 183);
            this.IBINOMBRE.Name = "IBINOMBRE";
            this.IBINOMBRE.Size = new System.Drawing.Size(111, 24);
            this.IBINOMBRE.TabIndex = 1;
            this.IBINOMBRE.Text = "NOMBRE :";
            this.IBINOMBRE.Click += new System.EventHandler(this.label2_Click);
            // 
            // IBIAPELLIDO
            // 
            this.IBIAPELLIDO.AutoSize = true;
            this.IBIAPELLIDO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIAPELLIDO.Location = new System.Drawing.Point(75, 237);
            this.IBIAPELLIDO.Name = "IBIAPELLIDO";
            this.IBIAPELLIDO.Size = new System.Drawing.Size(133, 24);
            this.IBIAPELLIDO.TabIndex = 2;
            this.IBIAPELLIDO.Text = "APLELLIDO :";
            this.IBIAPELLIDO.Click += new System.EventHandler(this.label3_Click);
            // 
            // IBICARGO
            // 
            this.IBICARGO.AutoSize = true;
            this.IBICARGO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBICARGO.Location = new System.Drawing.Point(112, 300);
            this.IBICARGO.Name = "IBICARGO";
            this.IBICARGO.Size = new System.Drawing.Size(96, 24);
            this.IBICARGO.TabIndex = 3;
            this.IBICARGO.Text = "CARGO :";
            this.IBICARGO.Click += new System.EventHandler(this.label4_Click);
            // 
            // IBISALARIO
            // 
            this.IBISALARIO.AutoSize = true;
            this.IBISALARIO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBISALARIO.Location = new System.Drawing.Point(99, 358);
            this.IBISALARIO.Name = "IBISALARIO";
            this.IBISALARIO.Size = new System.Drawing.Size(109, 24);
            this.IBISALARIO.TabIndex = 4;
            this.IBISALARIO.Text = "SALARIO :";
            // 
            // IBITELEFONO
            // 
            this.IBITELEFONO.AutoSize = true;
            this.IBITELEFONO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBITELEFONO.Location = new System.Drawing.Point(76, 435);
            this.IBITELEFONO.Name = "IBITELEFONO";
            this.IBITELEFONO.Size = new System.Drawing.Size(132, 24);
            this.IBITELEFONO.TabIndex = 5;
            this.IBITELEFONO.Text = "TELEFONO :";
            // 
            // IBICORREO
            // 
            this.IBICORREO.AutoSize = true;
            this.IBICORREO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBICORREO.Location = new System.Drawing.Point(97, 499);
            this.IBICORREO.Name = "IBICORREO";
            this.IBICORREO.Size = new System.Drawing.Size(110, 24);
            this.IBICORREO.TabIndex = 6;
            this.IBICORREO.Text = "CORREO :";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(266, 126);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(373, 26);
            this.txtID.TabIndex = 7;
            // 
            // TXTNOMBRE
            // 
            this.TXTNOMBRE.Location = new System.Drawing.Point(266, 181);
            this.TXTNOMBRE.Name = "TXTNOMBRE";
            this.TXTNOMBRE.Size = new System.Drawing.Size(373, 26);
            this.TXTNOMBRE.TabIndex = 8;
            // 
            // TXTAPELLIDO
            // 
            this.TXTAPELLIDO.Location = new System.Drawing.Point(266, 235);
            this.TXTAPELLIDO.Name = "TXTAPELLIDO";
            this.TXTAPELLIDO.Size = new System.Drawing.Size(373, 26);
            this.TXTAPELLIDO.TabIndex = 9;
            // 
            // TXTCARGO
            // 
            this.TXTCARGO.Location = new System.Drawing.Point(266, 298);
            this.TXTCARGO.Name = "TXTCARGO";
            this.TXTCARGO.Size = new System.Drawing.Size(373, 26);
            this.TXTCARGO.TabIndex = 10;
            // 
            // TXTSALARIO
            // 
            this.TXTSALARIO.Location = new System.Drawing.Point(266, 367);
            this.TXTSALARIO.Name = "TXTSALARIO";
            this.TXTSALARIO.Size = new System.Drawing.Size(373, 26);
            this.TXTSALARIO.TabIndex = 11;
            this.TXTSALARIO.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // TXTTELEFONO
            // 
            this.TXTTELEFONO.Location = new System.Drawing.Point(266, 433);
            this.TXTTELEFONO.Name = "TXTTELEFONO";
            this.TXTTELEFONO.Size = new System.Drawing.Size(373, 26);
            this.TXTTELEFONO.TabIndex = 12;
            // 
            // TXTCORREO
            // 
            this.TXTCORREO.Location = new System.Drawing.Point(266, 497);
            this.TXTCORREO.Name = "TXTCORREO";
            this.TXTCORREO.Size = new System.Drawing.Size(373, 26);
            this.TXTCORREO.TabIndex = 13;
            // 
            // BTNAGREGAR
            // 
            this.BTNAGREGAR.BackColor = System.Drawing.Color.Black;
            this.BTNAGREGAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNAGREGAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNAGREGAR.Location = new System.Drawing.Point(280, 634);
            this.BTNAGREGAR.Name = "BTNAGREGAR";
            this.BTNAGREGAR.Size = new System.Drawing.Size(216, 48);
            this.BTNAGREGAR.TabIndex = 14;
            this.BTNAGREGAR.Text = "AGREGAR";
            this.BTNAGREGAR.UseVisualStyleBackColor = false;
            this.BTNAGREGAR.Click += new System.EventHandler(this.BTNREGISTAREMPLEADO_Click);
            // 
            // IBIEMPLEADOS
            // 
            this.IBIEMPLEADOS.AutoSize = true;
            this.IBIEMPLEADOS.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIEMPLEADOS.Location = new System.Drawing.Point(186, 56);
            this.IBIEMPLEADOS.Name = "IBIEMPLEADOS";
            this.IBIEMPLEADOS.Size = new System.Drawing.Size(274, 24);
            this.IBIEMPLEADOS.TabIndex = 15;
            this.IBIEMPLEADOS.Text = "BIENVENIDOS EMPLEADOS";
            this.IBIEMPLEADOS.Click += new System.EventHandler(this.IBIEMPLEADOS_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(682, 126);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(283, 390);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // IBIFECHA
            // 
            this.IBIFECHA.AutoSize = true;
            this.IBIFECHA.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIFECHA.Location = new System.Drawing.Point(120, 557);
            this.IBIFECHA.Name = "IBIFECHA";
            this.IBIFECHA.Size = new System.Drawing.Size(88, 24);
            this.IBIFECHA.TabIndex = 18;
            this.IBIFECHA.Text = "FECHA :";
            // 
            // TXTFECHA
            // 
            this.TXTFECHA.Location = new System.Drawing.Point(266, 557);
            this.TXTFECHA.Name = "TXTFECHA";
            this.TXTFECHA.Size = new System.Drawing.Size(373, 26);
            this.TXTFECHA.TabIndex = 19;
            // 
            // BTNELIMINAR
            // 
            this.BTNELIMINAR.BackColor = System.Drawing.Color.Black;
            this.BTNELIMINAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNELIMINAR.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BTNELIMINAR.Location = new System.Drawing.Point(37, 634);
            this.BTNELIMINAR.Name = "BTNELIMINAR";
            this.BTNELIMINAR.Size = new System.Drawing.Size(200, 48);
            this.BTNELIMINAR.TabIndex = 20;
            this.BTNELIMINAR.Text = "ELIMINAR";
            this.BTNELIMINAR.UseVisualStyleBackColor = false;
            // 
            // BTNBUSCAR
            // 
            this.BTNBUSCAR.BackColor = System.Drawing.Color.Black;
            this.BTNBUSCAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNBUSCAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNBUSCAR.Location = new System.Drawing.Point(539, 634);
            this.BTNBUSCAR.Name = "BTNBUSCAR";
            this.BTNBUSCAR.Size = new System.Drawing.Size(197, 48);
            this.BTNBUSCAR.TabIndex = 21;
            this.BTNBUSCAR.Text = "BUSCAR";
            this.BTNBUSCAR.UseVisualStyleBackColor = false;
            // 
            // BTNMODIFICAR
            // 
            this.BTNMODIFICAR.BackColor = System.Drawing.Color.Black;
            this.BTNMODIFICAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNMODIFICAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNMODIFICAR.Location = new System.Drawing.Point(794, 634);
            this.BTNMODIFICAR.Name = "BTNMODIFICAR";
            this.BTNMODIFICAR.Size = new System.Drawing.Size(132, 48);
            this.BTNMODIFICAR.TabIndex = 22;
            this.BTNMODIFICAR.Text = "MODIFICAR";
            this.BTNMODIFICAR.UseVisualStyleBackColor = false;
            // 
            // FrmEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1006, 704);
            this.Controls.Add(this.BTNMODIFICAR);
            this.Controls.Add(this.BTNBUSCAR);
            this.Controls.Add(this.BTNELIMINAR);
            this.Controls.Add(this.TXTFECHA);
            this.Controls.Add(this.IBIFECHA);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.IBIEMPLEADOS);
            this.Controls.Add(this.BTNAGREGAR);
            this.Controls.Add(this.TXTCORREO);
            this.Controls.Add(this.TXTTELEFONO);
            this.Controls.Add(this.TXTSALARIO);
            this.Controls.Add(this.TXTCARGO);
            this.Controls.Add(this.TXTAPELLIDO);
            this.Controls.Add(this.TXTNOMBRE);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.IBICORREO);
            this.Controls.Add(this.IBITELEFONO);
            this.Controls.Add(this.IBISALARIO);
            this.Controls.Add(this.IBICARGO);
            this.Controls.Add(this.IBIAPELLIDO);
            this.Controls.Add(this.IBINOMBRE);
            this.Controls.Add(this.lblID);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "FrmEmpleado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Empleado";
            this.Load += new System.EventHandler(this.FrmEmpleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label IBINOMBRE;
        private System.Windows.Forms.Label IBIAPELLIDO;
        private System.Windows.Forms.Label IBICARGO;
        private System.Windows.Forms.Label IBISALARIO;
        private System.Windows.Forms.Label IBITELEFONO;
        private System.Windows.Forms.Label IBICORREO;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox TXTNOMBRE;
        private System.Windows.Forms.TextBox TXTAPELLIDO;
        private System.Windows.Forms.TextBox TXTCARGO;
        private System.Windows.Forms.TextBox TXTSALARIO;
        private System.Windows.Forms.TextBox TXTTELEFONO;
        private System.Windows.Forms.TextBox TXTCORREO;
        private System.Windows.Forms.Button BTNAGREGAR;
        private System.Windows.Forms.Label IBIEMPLEADOS;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label IBIFECHA;
        private System.Windows.Forms.TextBox TXTFECHA;
        private System.Windows.Forms.Button BTNELIMINAR;
        private System.Windows.Forms.Button BTNBUSCAR;
        private System.Windows.Forms.Button BTNMODIFICAR;
    }
}