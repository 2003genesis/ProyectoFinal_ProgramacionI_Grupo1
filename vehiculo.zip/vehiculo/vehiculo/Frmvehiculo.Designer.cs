﻿namespace vehiculo
{
    partial class Frmvehiculo
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmvehiculo));
            this.btnAGREGAR = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNBUSCAR = new System.Windows.Forms.Button();
            this.btnMODIFICAR = new System.Windows.Forms.Button();
            this.IBIMATRICULA = new System.Windows.Forms.Label();
            this.IBIMARCA = new System.Windows.Forms.Label();
            this.IBIMODELO = new System.Windows.Forms.Label();
            this.IBIAÑO = new System.Windows.Forms.Label();
            this.IBICOLOR = new System.Windows.Forms.Label();
            this.IBITIPO = new System.Windows.Forms.Label();
            this.IBIPROPIEDAD = new System.Windows.Forms.Label();
            this.IBIFECHA = new System.Windows.Forms.Label();
            this.TXTMATRICULA = new System.Windows.Forms.TextBox();
            this.TXTMARCA = new System.Windows.Forms.TextBox();
            this.TXTMODELO = new System.Windows.Forms.TextBox();
            this.TXTAÑO = new System.Windows.Forms.TextBox();
            this.TXTCOLOR = new System.Windows.Forms.TextBox();
            this.TXTTIPO = new System.Windows.Forms.TextBox();
            this.TXTPROPIEDAD = new System.Windows.Forms.TextBox();
            this.TXTFECHA = new System.Windows.Forms.TextBox();
            this.IBINUEVOVEHICULO = new System.Windows.Forms.Label();
            this.BTNELIMINAR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAGREGAR
            // 
            this.btnAGREGAR.BackColor = System.Drawing.Color.Black;
            this.btnAGREGAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAGREGAR.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAGREGAR.Location = new System.Drawing.Point(266, 550);
            this.btnAGREGAR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAGREGAR.Name = "btnAGREGAR";
            this.btnAGREGAR.Size = new System.Drawing.Size(278, 44);
            this.btnAGREGAR.TabIndex = 2;
            this.btnAGREGAR.Text = "AGREGAR";
            this.btnAGREGAR.UseVisualStyleBackColor = false;
            this.btnAGREGAR.Click += new System.EventHandler(this.btnRESGISTRAR_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(471, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(441, 401);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // BTNBUSCAR
            // 
            this.BTNBUSCAR.BackColor = System.Drawing.Color.Black;
            this.BTNBUSCAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNBUSCAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNBUSCAR.Location = new System.Drawing.Point(577, 553);
            this.BTNBUSCAR.Name = "BTNBUSCAR";
            this.BTNBUSCAR.Size = new System.Drawing.Size(178, 41);
            this.BTNBUSCAR.TabIndex = 19;
            this.BTNBUSCAR.Text = "BUSCAR";
            this.BTNBUSCAR.UseVisualStyleBackColor = false;
            // 
            // btnMODIFICAR
            // 
            this.btnMODIFICAR.BackColor = System.Drawing.Color.Black;
            this.btnMODIFICAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMODIFICAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMODIFICAR.Location = new System.Drawing.Point(782, 553);
            this.btnMODIFICAR.Name = "btnMODIFICAR";
            this.btnMODIFICAR.Size = new System.Drawing.Size(130, 41);
            this.btnMODIFICAR.TabIndex = 20;
            this.btnMODIFICAR.Text = "MODIFICAR";
            this.btnMODIFICAR.UseVisualStyleBackColor = false;
            // 
            // IBIMATRICULA
            // 
            this.IBIMATRICULA.AutoSize = true;
            this.IBIMATRICULA.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIMATRICULA.Location = new System.Drawing.Point(66, 65);
            this.IBIMATRICULA.Name = "IBIMATRICULA";
            this.IBIMATRICULA.Size = new System.Drawing.Size(160, 28);
            this.IBIMATRICULA.TabIndex = 21;
            this.IBIMATRICULA.Text = "MATRICULA :";
            // 
            // IBIMARCA
            // 
            this.IBIMARCA.AutoSize = true;
            this.IBIMARCA.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIMARCA.Location = new System.Drawing.Point(66, 138);
            this.IBIMARCA.Name = "IBIMARCA";
            this.IBIMARCA.Size = new System.Drawing.Size(109, 28);
            this.IBIMARCA.TabIndex = 22;
            this.IBIMARCA.Text = "MARCA :";
            // 
            // IBIMODELO
            // 
            this.IBIMODELO.AutoSize = true;
            this.IBIMODELO.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIMODELO.Location = new System.Drawing.Point(66, 203);
            this.IBIMODELO.Name = "IBIMODELO";
            this.IBIMODELO.Size = new System.Drawing.Size(122, 28);
            this.IBIMODELO.TabIndex = 23;
            this.IBIMODELO.Text = "MODELO :";
            // 
            // IBIAÑO
            // 
            this.IBIAÑO.AutoSize = true;
            this.IBIAÑO.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIAÑO.Location = new System.Drawing.Point(66, 261);
            this.IBIAÑO.Name = "IBIAÑO";
            this.IBIAÑO.Size = new System.Drawing.Size(83, 28);
            this.IBIAÑO.TabIndex = 24;
            this.IBIAÑO.Text = "AÑO  :";
            // 
            // IBICOLOR
            // 
            this.IBICOLOR.AutoSize = true;
            this.IBICOLOR.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBICOLOR.Location = new System.Drawing.Point(66, 318);
            this.IBICOLOR.Name = "IBICOLOR";
            this.IBICOLOR.Size = new System.Drawing.Size(112, 28);
            this.IBICOLOR.TabIndex = 25;
            this.IBICOLOR.Text = "COLOR  :";
            // 
            // IBITIPO
            // 
            this.IBITIPO.AutoSize = true;
            this.IBITIPO.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBITIPO.Location = new System.Drawing.Point(66, 380);
            this.IBITIPO.Name = "IBITIPO";
            this.IBITIPO.Size = new System.Drawing.Size(79, 28);
            this.IBITIPO.TabIndex = 26;
            this.IBITIPO.Text = "TIPO :";
            // 
            // IBIPROPIEDAD
            // 
            this.IBIPROPIEDAD.AutoSize = true;
            this.IBIPROPIEDAD.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIPROPIEDAD.Location = new System.Drawing.Point(66, 442);
            this.IBIPROPIEDAD.Name = "IBIPROPIEDAD";
            this.IBIPROPIEDAD.Size = new System.Drawing.Size(142, 28);
            this.IBIPROPIEDAD.TabIndex = 27;
            this.IBIPROPIEDAD.Text = "PROPIEDAD";
            // 
            // IBIFECHA
            // 
            this.IBIFECHA.AutoSize = true;
            this.IBIFECHA.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIFECHA.Location = new System.Drawing.Point(66, 507);
            this.IBIFECHA.Name = "IBIFECHA";
            this.IBIFECHA.Size = new System.Drawing.Size(102, 28);
            this.IBIFECHA.TabIndex = 28;
            this.IBIFECHA.Text = "FECHA :";
            // 
            // TXTMATRICULA
            // 
            this.TXTMATRICULA.Location = new System.Drawing.Point(244, 61);
            this.TXTMATRICULA.Name = "TXTMATRICULA";
            this.TXTMATRICULA.Size = new System.Drawing.Size(173, 32);
            this.TXTMATRICULA.TabIndex = 29;
            this.TXTMATRICULA.TextChanged += new System.EventHandler(this.TXTMATRICULA_TextChanged);
            // 
            // TXTMARCA
            // 
            this.TXTMARCA.Location = new System.Drawing.Point(244, 134);
            this.TXTMARCA.Name = "TXTMARCA";
            this.TXTMARCA.Size = new System.Drawing.Size(173, 32);
            this.TXTMARCA.TabIndex = 30;
            // 
            // TXTMODELO
            // 
            this.TXTMODELO.Location = new System.Drawing.Point(244, 199);
            this.TXTMODELO.Name = "TXTMODELO";
            this.TXTMODELO.Size = new System.Drawing.Size(173, 32);
            this.TXTMODELO.TabIndex = 31;
            // 
            // TXTAÑO
            // 
            this.TXTAÑO.Location = new System.Drawing.Point(244, 257);
            this.TXTAÑO.Name = "TXTAÑO";
            this.TXTAÑO.Size = new System.Drawing.Size(173, 32);
            this.TXTAÑO.TabIndex = 32;
            // 
            // TXTCOLOR
            // 
            this.TXTCOLOR.Location = new System.Drawing.Point(244, 314);
            this.TXTCOLOR.Name = "TXTCOLOR";
            this.TXTCOLOR.Size = new System.Drawing.Size(173, 32);
            this.TXTCOLOR.TabIndex = 33;
            this.TXTCOLOR.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // TXTTIPO
            // 
            this.TXTTIPO.Location = new System.Drawing.Point(244, 376);
            this.TXTTIPO.Name = "TXTTIPO";
            this.TXTTIPO.Size = new System.Drawing.Size(173, 32);
            this.TXTTIPO.TabIndex = 34;
            // 
            // TXTPROPIEDAD
            // 
            this.TXTPROPIEDAD.Location = new System.Drawing.Point(244, 438);
            this.TXTPROPIEDAD.Name = "TXTPROPIEDAD";
            this.TXTPROPIEDAD.Size = new System.Drawing.Size(173, 32);
            this.TXTPROPIEDAD.TabIndex = 35;
            // 
            // TXTFECHA
            // 
            this.TXTFECHA.Location = new System.Drawing.Point(244, 493);
            this.TXTFECHA.Name = "TXTFECHA";
            this.TXTFECHA.Size = new System.Drawing.Size(173, 32);
            this.TXTFECHA.TabIndex = 36;
            // 
            // IBINUEVOVEHICULO
            // 
            this.IBINUEVOVEHICULO.AutoSize = true;
            this.IBINUEVOVEHICULO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBINUEVOVEHICULO.Location = new System.Drawing.Point(357, 9);
            this.IBINUEVOVEHICULO.Name = "IBINUEVOVEHICULO";
            this.IBINUEVOVEHICULO.Size = new System.Drawing.Size(187, 24);
            this.IBINUEVOVEHICULO.TabIndex = 37;
            this.IBINUEVOVEHICULO.Text = "NUEVO VEHICULO";
            // 
            // BTNELIMINAR
            // 
            this.BTNELIMINAR.BackColor = System.Drawing.Color.Black;
            this.BTNELIMINAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNELIMINAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNELIMINAR.Location = new System.Drawing.Point(58, 556);
            this.BTNELIMINAR.Name = "BTNELIMINAR";
            this.BTNELIMINAR.Size = new System.Drawing.Size(149, 37);
            this.BTNELIMINAR.TabIndex = 38;
            this.BTNELIMINAR.Text = "ELIMINAR";
            this.BTNELIMINAR.UseVisualStyleBackColor = false;
            // 
            // Frmvehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(961, 615);
            this.Controls.Add(this.BTNELIMINAR);
            this.Controls.Add(this.IBINUEVOVEHICULO);
            this.Controls.Add(this.TXTFECHA);
            this.Controls.Add(this.TXTPROPIEDAD);
            this.Controls.Add(this.TXTTIPO);
            this.Controls.Add(this.TXTCOLOR);
            this.Controls.Add(this.TXTAÑO);
            this.Controls.Add(this.TXTMODELO);
            this.Controls.Add(this.TXTMARCA);
            this.Controls.Add(this.TXTMATRICULA);
            this.Controls.Add(this.IBIFECHA);
            this.Controls.Add(this.IBIPROPIEDAD);
            this.Controls.Add(this.IBITIPO);
            this.Controls.Add(this.IBICOLOR);
            this.Controls.Add(this.IBIAÑO);
            this.Controls.Add(this.IBIMODELO);
            this.Controls.Add(this.IBIMARCA);
            this.Controls.Add(this.IBIMATRICULA);
            this.Controls.Add(this.btnMODIFICAR);
            this.Controls.Add(this.BTNBUSCAR);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAGREGAR);
            this.Font = new System.Drawing.Font("Noto Sans Lisu", 8.999999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Frmvehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "vehiculo";
            this.TransparencyKey = System.Drawing.Color.Black;
            this.Load += new System.EventHandler(this.Frmvehiculo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAGREGAR;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNBUSCAR;
        private System.Windows.Forms.Button btnMODIFICAR;
        private System.Windows.Forms.Label IBIMATRICULA;
        private System.Windows.Forms.Label IBIMARCA;
        private System.Windows.Forms.Label IBIMODELO;
        private System.Windows.Forms.Label IBIAÑO;
        private System.Windows.Forms.Label IBICOLOR;
        private System.Windows.Forms.Label IBITIPO;
        private System.Windows.Forms.Label IBIPROPIEDAD;
        private System.Windows.Forms.Label IBIFECHA;
        private System.Windows.Forms.TextBox TXTMATRICULA;
        private System.Windows.Forms.TextBox TXTMARCA;
        private System.Windows.Forms.TextBox TXTMODELO;
        private System.Windows.Forms.TextBox TXTAÑO;
        private System.Windows.Forms.TextBox TXTCOLOR;
        private System.Windows.Forms.TextBox TXTTIPO;
        private System.Windows.Forms.TextBox TXTPROPIEDAD;
        private System.Windows.Forms.TextBox TXTFECHA;
        private System.Windows.Forms.Label IBINUEVOVEHICULO;
        private System.Windows.Forms.Button BTNELIMINAR;
    }
}

