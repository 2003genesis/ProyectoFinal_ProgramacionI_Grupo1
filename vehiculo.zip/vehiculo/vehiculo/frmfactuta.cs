﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vehiculo
{
    public partial class Frmfactura : Form
    {
        public Frmfactura()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btngenerarfactura_Click(object sender, EventArgs e)
        {              
        public partial class FormFactura : Form
        {
            private int contadorFacturas = 1; 

            public FormFactura()
            {
                InitializeComponent();
            }

            private void btnGenerarFactura_Click(object sender, EventArgs e)
            {
               
                string cliente = txtCliente.Text;
                string servicios = txtServicios.Text; 
                decimal total;

                if (!decimal.TryParse(txtTotal.Text, out total))
                {
                    MessageBox.Show("El total ingresado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

               
                List<string> listaServicios = new List<string>(servicios.Split(','));

                
                Factura factura = new Factura(contadorFacturas, cliente, listaServicios, total);
                contadorFacturas++;

               
                txtResultado.Text = factura.ObtenerDetalle();
            }
        }

        private void Frmfactura_Load(object sender, EventArgs e)
        {

        }

        private void TXTCLIENTES_TextChanged(object sender, EventArgs e)
        {

        }
    }

}