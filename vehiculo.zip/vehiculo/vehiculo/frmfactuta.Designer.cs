﻿namespace vehiculo
{
    partial class Frmfactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmfactura));
            this.lBICLIENTE = new System.Windows.Forms.Label();
            this.lBISERVICIOS = new System.Windows.Forms.Label();
            this.lBITOTAL = new System.Windows.Forms.Label();
            this.TXTCLIENTES = new System.Windows.Forms.TextBox();
            this.TXTSERVICIOS = new System.Windows.Forms.TextBox();
            this.TXTTOTAL = new System.Windows.Forms.TextBox();
            this.btnAGREGAR = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.IBIIMPUESTOS = new System.Windows.Forms.Label();
            this.TXTIMPUESTOS = new System.Windows.Forms.TextBox();
            this.IBISUBTOTAL = new System.Windows.Forms.Label();
            this.TXTSUBTOTAL = new System.Windows.Forms.TextBox();
            this.IBIVEHICULO = new System.Windows.Forms.Label();
            this.TXTVEHICULO = new System.Windows.Forms.TextBox();
            this.IBITELEFONO = new System.Windows.Forms.Label();
            this.TXTTELEFONO = new System.Windows.Forms.TextBox();
            this.IBIFECHA = new System.Windows.Forms.Label();
            this.TXTFECHA = new System.Windows.Forms.TextBox();
            this.BTNELIMINAR = new System.Windows.Forms.Button();
            this.BTNBUSCAR = new System.Windows.Forms.Button();
            this.BTNMODIFICAR = new System.Windows.Forms.Button();
            this.IBINUEVAFACTURA = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lBICLIENTE
            // 
            this.lBICLIENTE.AutoSize = true;
            this.lBICLIENTE.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBICLIENTE.Location = new System.Drawing.Point(116, 84);
            this.lBICLIENTE.Name = "lBICLIENTE";
            this.lBICLIENTE.Size = new System.Drawing.Size(107, 24);
            this.lBICLIENTE.TabIndex = 0;
            this.lBICLIENTE.Text = "CLIENTE :";
            this.lBICLIENTE.Click += new System.EventHandler(this.label1_Click);
            // 
            // lBISERVICIOS
            // 
            this.lBISERVICIOS.AutoSize = true;
            this.lBISERVICIOS.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBISERVICIOS.Location = new System.Drawing.Point(116, 138);
            this.lBISERVICIOS.Name = "lBISERVICIOS";
            this.lBISERVICIOS.Size = new System.Drawing.Size(123, 24);
            this.lBISERVICIOS.TabIndex = 1;
            this.lBISERVICIOS.Text = "SERVICIOS:";
            this.lBISERVICIOS.Click += new System.EventHandler(this.label2_Click);
            // 
            // lBITOTAL
            // 
            this.lBITOTAL.AutoSize = true;
            this.lBITOTAL.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBITOTAL.Location = new System.Drawing.Point(116, 457);
            this.lBITOTAL.Name = "lBITOTAL";
            this.lBITOTAL.Size = new System.Drawing.Size(89, 24);
            this.lBITOTAL.TabIndex = 2;
            this.lBITOTAL.Text = "TOTAL :";
            // 
            // TXTCLIENTES
            // 
            this.TXTCLIENTES.Location = new System.Drawing.Point(281, 78);
            this.TXTCLIENTES.Name = "TXTCLIENTES";
            this.TXTCLIENTES.Size = new System.Drawing.Size(382, 26);
            this.TXTCLIENTES.TabIndex = 3;
            this.TXTCLIENTES.TextChanged += new System.EventHandler(this.TXTCLIENTES_TextChanged);
            // 
            // TXTSERVICIOS
            // 
            this.TXTSERVICIOS.Location = new System.Drawing.Point(281, 132);
            this.TXTSERVICIOS.Name = "TXTSERVICIOS";
            this.TXTSERVICIOS.Size = new System.Drawing.Size(382, 26);
            this.TXTSERVICIOS.TabIndex = 4;
            // 
            // TXTTOTAL
            // 
            this.TXTTOTAL.Location = new System.Drawing.Point(282, 455);
            this.TXTTOTAL.Name = "TXTTOTAL";
            this.TXTTOTAL.Size = new System.Drawing.Size(382, 26);
            this.TXTTOTAL.TabIndex = 5;
            // 
            // btnAGREGAR
            // 
            this.btnAGREGAR.BackColor = System.Drawing.Color.Black;
            this.btnAGREGAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAGREGAR.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAGREGAR.Location = new System.Drawing.Point(281, 549);
            this.btnAGREGAR.Name = "btnAGREGAR";
            this.btnAGREGAR.Size = new System.Drawing.Size(271, 52);
            this.btnAGREGAR.TabIndex = 6;
            this.btnAGREGAR.Text = "AGREGAR";
            this.btnAGREGAR.UseVisualStyleBackColor = false;
            this.btnAGREGAR.Click += new System.EventHandler(this.btngenerarfactura_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(710, 78);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(275, 270);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // IBIIMPUESTOS
            // 
            this.IBIIMPUESTOS.AutoSize = true;
            this.IBIIMPUESTOS.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIIMPUESTOS.Location = new System.Drawing.Point(116, 194);
            this.IBIIMPUESTOS.Name = "IBIIMPUESTOS";
            this.IBIIMPUESTOS.Size = new System.Drawing.Size(140, 24);
            this.IBIIMPUESTOS.TabIndex = 8;
            this.IBIIMPUESTOS.Text = "IMPUESTOS :";
            // 
            // TXTIMPUESTOS
            // 
            this.TXTIMPUESTOS.Location = new System.Drawing.Point(281, 188);
            this.TXTIMPUESTOS.Name = "TXTIMPUESTOS";
            this.TXTIMPUESTOS.Size = new System.Drawing.Size(382, 26);
            this.TXTIMPUESTOS.TabIndex = 9;
            // 
            // IBISUBTOTAL
            // 
            this.IBISUBTOTAL.AutoSize = true;
            this.IBISUBTOTAL.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBISUBTOTAL.Location = new System.Drawing.Point(109, 403);
            this.IBISUBTOTAL.Name = "IBISUBTOTAL";
            this.IBISUBTOTAL.Size = new System.Drawing.Size(130, 24);
            this.IBISUBTOTAL.TabIndex = 10;
            this.IBISUBTOTAL.Text = "SUBTOTAL :";
            // 
            // TXTSUBTOTAL
            // 
            this.TXTSUBTOTAL.Location = new System.Drawing.Point(281, 401);
            this.TXTSUBTOTAL.Name = "TXTSUBTOTAL";
            this.TXTSUBTOTAL.Size = new System.Drawing.Size(382, 26);
            this.TXTSUBTOTAL.TabIndex = 11;
            // 
            // IBIVEHICULO
            // 
            this.IBIVEHICULO.AutoSize = true;
            this.IBIVEHICULO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIVEHICULO.Location = new System.Drawing.Point(116, 250);
            this.IBIVEHICULO.Name = "IBIVEHICULO";
            this.IBIVEHICULO.Size = new System.Drawing.Size(124, 24);
            this.IBIVEHICULO.TabIndex = 12;
            this.IBIVEHICULO.Text = "VEHICULO :";
            // 
            // TXTVEHICULO
            // 
            this.TXTVEHICULO.Location = new System.Drawing.Point(281, 244);
            this.TXTVEHICULO.Name = "TXTVEHICULO";
            this.TXTVEHICULO.Size = new System.Drawing.Size(382, 26);
            this.TXTVEHICULO.TabIndex = 13;
            // 
            // IBITELEFONO
            // 
            this.IBITELEFONO.AutoSize = true;
            this.IBITELEFONO.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBITELEFONO.Location = new System.Drawing.Point(116, 304);
            this.IBITELEFONO.Name = "IBITELEFONO";
            this.IBITELEFONO.Size = new System.Drawing.Size(132, 24);
            this.IBITELEFONO.TabIndex = 14;
            this.IBITELEFONO.Text = "TELEFONO :";
            // 
            // TXTTELEFONO
            // 
            this.TXTTELEFONO.Location = new System.Drawing.Point(281, 298);
            this.TXTTELEFONO.Name = "TXTTELEFONO";
            this.TXTTELEFONO.Size = new System.Drawing.Size(382, 26);
            this.TXTTELEFONO.TabIndex = 15;
            // 
            // IBIFECHA
            // 
            this.IBIFECHA.AutoSize = true;
            this.IBIFECHA.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBIFECHA.Location = new System.Drawing.Point(116, 358);
            this.IBIFECHA.Name = "IBIFECHA";
            this.IBIFECHA.Size = new System.Drawing.Size(88, 24);
            this.IBIFECHA.TabIndex = 16;
            this.IBIFECHA.Text = "FECHA :";
            // 
            // TXTFECHA
            // 
            this.TXTFECHA.Location = new System.Drawing.Point(281, 352);
            this.TXTFECHA.Name = "TXTFECHA";
            this.TXTFECHA.Size = new System.Drawing.Size(382, 26);
            this.TXTFECHA.TabIndex = 17;
            // 
            // BTNELIMINAR
            // 
            this.BTNELIMINAR.BackColor = System.Drawing.Color.Black;
            this.BTNELIMINAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNELIMINAR.ForeColor = System.Drawing.Color.White;
            this.BTNELIMINAR.Location = new System.Drawing.Point(30, 549);
            this.BTNELIMINAR.Name = "BTNELIMINAR";
            this.BTNELIMINAR.Size = new System.Drawing.Size(209, 52);
            this.BTNELIMINAR.TabIndex = 18;
            this.BTNELIMINAR.Text = "ELIMINAR";
            this.BTNELIMINAR.UseVisualStyleBackColor = false;
            // 
            // BTNBUSCAR
            // 
            this.BTNBUSCAR.BackColor = System.Drawing.Color.Black;
            this.BTNBUSCAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNBUSCAR.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BTNBUSCAR.Location = new System.Drawing.Point(587, 549);
            this.BTNBUSCAR.Name = "BTNBUSCAR";
            this.BTNBUSCAR.Size = new System.Drawing.Size(213, 52);
            this.BTNBUSCAR.TabIndex = 19;
            this.BTNBUSCAR.Text = "BUSCAR";
            this.BTNBUSCAR.UseVisualStyleBackColor = false;
            // 
            // BTNMODIFICAR
            // 
            this.BTNMODIFICAR.BackColor = System.Drawing.Color.Black;
            this.BTNMODIFICAR.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNMODIFICAR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNMODIFICAR.Location = new System.Drawing.Point(848, 547);
            this.BTNMODIFICAR.Name = "BTNMODIFICAR";
            this.BTNMODIFICAR.Size = new System.Drawing.Size(137, 53);
            this.BTNMODIFICAR.TabIndex = 20;
            this.BTNMODIFICAR.Text = "MODIFICAR";
            this.BTNMODIFICAR.UseVisualStyleBackColor = false;
            // 
            // IBINUEVAFACTURA
            // 
            this.IBINUEVAFACTURA.AutoSize = true;
            this.IBINUEVAFACTURA.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.IBINUEVAFACTURA.Location = new System.Drawing.Point(277, 25);
            this.IBINUEVAFACTURA.Name = "IBINUEVAFACTURA";
            this.IBINUEVAFACTURA.Size = new System.Drawing.Size(202, 26);
            this.IBINUEVAFACTURA.TabIndex = 21;
            this.IBINUEVAFACTURA.Text = "NUEVA FACTURA ";
            // 
            // Frmfactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1026, 652);
            this.Controls.Add(this.IBINUEVAFACTURA);
            this.Controls.Add(this.BTNMODIFICAR);
            this.Controls.Add(this.BTNBUSCAR);
            this.Controls.Add(this.BTNELIMINAR);
            this.Controls.Add(this.TXTFECHA);
            this.Controls.Add(this.IBIFECHA);
            this.Controls.Add(this.TXTTELEFONO);
            this.Controls.Add(this.IBITELEFONO);
            this.Controls.Add(this.TXTVEHICULO);
            this.Controls.Add(this.IBIVEHICULO);
            this.Controls.Add(this.TXTSUBTOTAL);
            this.Controls.Add(this.IBISUBTOTAL);
            this.Controls.Add(this.TXTIMPUESTOS);
            this.Controls.Add(this.IBIIMPUESTOS);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAGREGAR);
            this.Controls.Add(this.TXTTOTAL);
            this.Controls.Add(this.TXTSERVICIOS);
            this.Controls.Add(this.TXTCLIENTES);
            this.Controls.Add(this.lBITOTAL);
            this.Controls.Add(this.lBISERVICIOS);
            this.Controls.Add(this.lBICLIENTE);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frmfactura";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "factura";
            this.Load += new System.EventHandler(this.Frmfactura_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lBICLIENTE;
        private System.Windows.Forms.Label lBISERVICIOS;
        private System.Windows.Forms.Label lBITOTAL;
        private System.Windows.Forms.TextBox TXTCLIENTES;
        private System.Windows.Forms.TextBox TXTSERVICIOS;
        private System.Windows.Forms.TextBox TXTTOTAL;
        private System.Windows.Forms.Button btnAGREGAR;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label IBIIMPUESTOS;
        private System.Windows.Forms.TextBox TXTIMPUESTOS;
        private System.Windows.Forms.Label IBISUBTOTAL;
        private System.Windows.Forms.TextBox TXTSUBTOTAL;
        private System.Windows.Forms.Label IBIVEHICULO;
        private System.Windows.Forms.TextBox TXTVEHICULO;
        private System.Windows.Forms.Label IBITELEFONO;
        private System.Windows.Forms.TextBox TXTTELEFONO;
        private System.Windows.Forms.Label IBIFECHA;
        private System.Windows.Forms.TextBox TXTFECHA;
        private System.Windows.Forms.Button BTNELIMINAR;
        private System.Windows.Forms.Button BTNBUSCAR;
        private System.Windows.Forms.Button BTNMODIFICAR;
        private System.Windows.Forms.Label IBINUEVAFACTURA;
    }
}