﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vehiculo
{
    public partial class Frmvehiculo : Form
    {
        public Frmvehiculo()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnRESGISTRAR_Click(object sender, EventArgs e)
        {
private void txttxtResultado_TextChanged(object sender, EventArgs e)
        {
private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txttipo_TextChanged(object sender, EventArgs e)
        {

        }

        private void IBIMARCA_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtpropietario_TextChanged(object sender, EventArgs e)
        {

        }

        private void Frmvehiculo_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void TXTMATRICULA_TextChanged(object sender, EventArgs e)
        {

        }namespace TallerMecanico
    {
        public partial class FormVehiculo : Form
        {
            public FormVehiculo()
            {
                InitializeComponent();
            }

            private void btnRegistrar_Click(object sender, EventArgs e)
            {
               
                string matricula = txtMatricula.Text;
                string marca = txtMarca.Text;
                string modelo = txtModelo.Text;
                int anio = int.Parse(txtAnio.Text);
                string color = txtColor.Text;
                string tipo = txtTipo.Text;
                string propietario = txtPropietario.Text;

              
                Vehiculo vehiculo = new Vehiculo(matricula, marca, modelo, anio, color, tipo, propietario);

          
                if (!vehiculo.ValidarAnio())
                {
                    MessageBox.Show("El año ingresado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

              
                txtResultado.Text = vehiculo.ObtenerInformacion();
            }
        }
    }

}
    