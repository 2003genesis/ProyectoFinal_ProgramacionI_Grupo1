﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static vehiculo.FrmEmpleado;

namespace vehiculo
{
    public partial class frmMecanico : Form
    {
        public frmMecanico()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void IBIcertificaciones_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegistrarmecanico_Click(object sender, EventArgs e)
        {
           
        public class Mecanico : Empleado
        {
      
            public string Especialidad { get; set; } 
            public int Experiencia { get; set; } 
            public string Certificaciones { get; set; } 


            public Mecanico(string id, string nombre, string apellido, string cargo, decimal salario, string telefono, string correo,
                            string especialidad, int experiencia, string certificaciones)
                : base(id, nombre, apellido, cargo, salario, telefono, correo)
            {
                Especialidad = especialidad;
                Experiencia = experiencia;
                Certificaciones = certificaciones;
            }

       
            public string ObtenerInformacionMecanico()
            {
                return $"{ObtenerInformacion()}\n" +
                       $"Especialidad: {Especialidad}\n" +
                       $"Años de Experiencia: {Experiencia}\n" +
                       $"Certificaciones: {Certificaciones}";
            }

    
            public partial class FormMecanico : Form
            {
                public FormMecanico()
                {
                    InitializeComponent();
                }

                private void btnRegistrarMecanico_Click(object sender, EventArgs e)
                {
             
                    string id = txtID.Text;
                    string nombre = txtNombre.Text;
                    string apellido = txtApellido.Text;
                    string cargo = "Mecánico";
                    decimal salario;

                    if (!decimal.TryParse(txtSalario.Text, out salario))
                    {
                        MessageBox.Show("El salario ingresado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string telefono = txtTelefono.Text;
                    string correo = txtCorreo.Text;
                    string especialidad = txtEspecialidad.Text;
                    int experiencia;

                    if (!int.TryParse(txtExperiencia.Text, out experiencia))
                    {
                        MessageBox.Show("La experiencia debe ser un número entero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string certificaciones = txtCertificaciones.Text;

            
                    Mecanico mecanico = new Mecanico(id, nombre, apellido, cargo, salario, telefono, correo, especialidad, experiencia, certificaciones);

        
                    if (!mecanico.ValidarCorreo())
                    {
                        MessageBox.Show("El correo electrónico no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!mecanico.ValidarTelefono())
                    {
                        MessageBox.Show("El teléfono debe tener 8 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    txtResultado.Text = mecanico.ObtenerInformacionMecanico();
                }
            }
        }

        private void frmMecanico_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void BTNAGREGAR_Click(object sender, EventArgs e)
        {

        }
    }
}
