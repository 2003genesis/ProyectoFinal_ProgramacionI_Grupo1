﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static vehiculo.FrmEmpleado;

namespace vehiculo
{
    public partial class FrmEmpleado : Form
    {
        public FrmEmpleado()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNREGISTAREMPLEADO_Click(object sender, EventArgs e)
        {
           
        public class Empleado
        {
           
            public string ID { get; set; }
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public string Cargo { get; set; } 
            public decimal Salario { get; set; }
            public string Telefono { get; set; }
            public string Correo { get; set; }
            public DateTime FechaContratacion { get; private set; }

     
            public Empleado(string id, string nombre, string apellido, string cargo, decimal salario, string telefono, string correo)
            {
                ID = id;
                Nombre = nombre;
                Apellido = apellido;
                Cargo = cargo;
                Salario = salario;
                Telefono = telefono;
                Correo = correo;
                FechaContratacion = DateTime.Now;
            }

   
            public bool ValidarCorreo()
            {
                return Correo.Contains("@") && Correo.Contains(".");
            }

            public bool ValidarTelefono()
            {
                return Telefono.Length == 8 && long.TryParse(Telefono, out _);
            }

            public string ObtenerInformacion()
            {
                return $"Empleado: {Nombre} {Apellido}\n" +
                       $"ID: {ID}\n" +
                       $"Cargo: {Cargo}\n" +
                       $"Salario: {Salario:C}\n" +
                       $"Teléfono: {Telefono}\n" +
                       $"Correo: {Correo}\n" +
                       $"Fecha de Contratación: {FechaContratacion.ToShortDateString()}";
            }
    
        public partial class FormEmpleado : Form
        {
            public FormEmpleado()
            {
          

            private void btnRegistrarEmpleado_Click(object sender, EventArgs e)
            {
              
                string id = txtID.Text;
                string nombre = txtNombre.Text;
                string apellido = txtApellido.Text;
                string cargo = txtCargo.Text;
                decimal salario;

                if (decimal.TryParse(txtSalario.Text, out salario))
                {
                    MessageBox.Show("El salario ingresado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string telefono = txtTelefono.Text;
                string correo = txtCorreo.Text;

                Empleado empleado = new Empleado(id, nombre, apellido, cargo, salario, telefono, correo);

              
                if (!empleado.ValidarCorreo())
                {
                    MessageBox.Show("El correo electrónico no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!empleado.ValidarTelefono())
                {
                    MessageBox.Show("El teléfono debe tener 8 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

             
                txtResultado.Text = empleado.ObtenerInformacion();
            }
        }
    }

        private void TXTRESULTADO_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmEmpleado_Load(object sender, EventArgs e)
        {

        }

        private void IBIEMPLEADOS_Click(object sender, EventArgs e)
        {

        }
    }
}