﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TALLER_MECANICO_FORMS_CLAUDIA
{
    public partial class FRMCITA : Form
    {
        public FRMCITA()
        {
            InitializeComponent();
        }

        private void Cita_Load(object sender, EventArgs e)
        {

        }
    }
}
