﻿namespace TALLER_MECANICO_FORMS_CLAUDIA
{
    partial class FRMIVENTARIO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMIVENTARIO));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtidinventario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtnomproducto = new System.Windows.Forms.TextBox();
            this.txtcantidadinventario = new System.Windows.Forms.TextBox();
            this.txtpreciocompra = new System.Windows.Forms.TextBox();
            this.txtventainventario = new System.Windows.Forms.TextBox();
            this.txtfechinventario = new System.Windows.Forms.TextBox();
            this.cmbxcategoriainventario = new System.Windows.Forms.ComboBox();
            this.cmbxestadoinventario = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnguardarinventario = new System.Windows.Forms.Button();
            this.btnmodificarinventario = new System.Windows.Forms.Button();
            this.btnagregarinventario = new System.Windows.Forms.Button();
            this.btneliminarinventario = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(355, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "REGISTRO DE INVENTARIO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "N°:";
            // 
            // txtidinventario
            // 
            this.txtidinventario.Location = new System.Drawing.Point(319, 137);
            this.txtidinventario.Name = "txtidinventario";
            this.txtidinventario.Size = new System.Drawing.Size(263, 26);
            this.txtidinventario.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre Producto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(52, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "Categoria:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(52, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(254, 29);
            this.label5.TabIndex = 5;
            this.label5.Text = "Cantidad Disponible:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(52, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(190, 29);
            this.label6.TabIndex = 6;
            this.label6.Text = "Precio Compra:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(52, 364);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 29);
            this.label7.TabIndex = 7;
            this.label7.Text = "Precio Venta:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(52, 415);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 29);
            this.label8.TabIndex = 8;
            this.label8.Text = "Fecha Ingreso:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(52, 460);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 29);
            this.label9.TabIndex = 9;
            this.label9.Text = "Estado:";
            // 
            // txtnomproducto
            // 
            this.txtnomproducto.Location = new System.Drawing.Point(319, 181);
            this.txtnomproducto.Name = "txtnomproducto";
            this.txtnomproducto.Size = new System.Drawing.Size(263, 26);
            this.txtnomproducto.TabIndex = 10;
            // 
            // txtcantidadinventario
            // 
            this.txtcantidadinventario.Location = new System.Drawing.Point(319, 277);
            this.txtcantidadinventario.Name = "txtcantidadinventario";
            this.txtcantidadinventario.Size = new System.Drawing.Size(263, 26);
            this.txtcantidadinventario.TabIndex = 12;
            // 
            // txtpreciocompra
            // 
            this.txtpreciocompra.Location = new System.Drawing.Point(319, 323);
            this.txtpreciocompra.Name = "txtpreciocompra";
            this.txtpreciocompra.Size = new System.Drawing.Size(263, 26);
            this.txtpreciocompra.TabIndex = 13;
            // 
            // txtventainventario
            // 
            this.txtventainventario.Location = new System.Drawing.Point(319, 368);
            this.txtventainventario.Name = "txtventainventario";
            this.txtventainventario.Size = new System.Drawing.Size(263, 26);
            this.txtventainventario.TabIndex = 14;
            // 
            // txtfechinventario
            // 
            this.txtfechinventario.Location = new System.Drawing.Point(319, 419);
            this.txtfechinventario.Name = "txtfechinventario";
            this.txtfechinventario.Size = new System.Drawing.Size(263, 26);
            this.txtfechinventario.TabIndex = 15;
            // 
            // cmbxcategoriainventario
            // 
            this.cmbxcategoriainventario.FormattingEnabled = true;
            this.cmbxcategoriainventario.Items.AddRange(new object[] {
            "Respuesto",
            "Lubricantes",
            "Accesorios",
            "Herramientas",
            "Neumaticos",
            "Batería",
            "Producto de Limpieza",
            "Sistemas Electricos",
            "Suspensión y Dirección"});
            this.cmbxcategoriainventario.Location = new System.Drawing.Point(319, 229);
            this.cmbxcategoriainventario.Name = "cmbxcategoriainventario";
            this.cmbxcategoriainventario.Size = new System.Drawing.Size(263, 28);
            this.cmbxcategoriainventario.TabIndex = 17;
            // 
            // cmbxestadoinventario
            // 
            this.cmbxestadoinventario.FormattingEnabled = true;
            this.cmbxestadoinventario.Items.AddRange(new object[] {
            "Activo",
            "Inactivo"});
            this.cmbxestadoinventario.Location = new System.Drawing.Point(319, 464);
            this.cmbxestadoinventario.Name = "cmbxestadoinventario";
            this.cmbxestadoinventario.Size = new System.Drawing.Size(263, 28);
            this.cmbxestadoinventario.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(634, 148);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(328, 321);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // btnguardarinventario
            // 
            this.btnguardarinventario.BackColor = System.Drawing.Color.Black;
            this.btnguardarinventario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardarinventario.ForeColor = System.Drawing.Color.White;
            this.btnguardarinventario.Location = new System.Drawing.Point(113, 548);
            this.btnguardarinventario.Name = "btnguardarinventario";
            this.btnguardarinventario.Size = new System.Drawing.Size(140, 48);
            this.btnguardarinventario.TabIndex = 20;
            this.btnguardarinventario.Text = "Guardar";
            this.btnguardarinventario.UseVisualStyleBackColor = false;
            this.btnguardarinventario.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnmodificarinventario
            // 
            this.btnmodificarinventario.BackColor = System.Drawing.Color.Black;
            this.btnmodificarinventario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodificarinventario.ForeColor = System.Drawing.Color.White;
            this.btnmodificarinventario.Location = new System.Drawing.Point(319, 548);
            this.btnmodificarinventario.Name = "btnmodificarinventario";
            this.btnmodificarinventario.Size = new System.Drawing.Size(140, 48);
            this.btnmodificarinventario.TabIndex = 21;
            this.btnmodificarinventario.Text = "Modificar";
            this.btnmodificarinventario.UseVisualStyleBackColor = false;
            // 
            // btnagregarinventario
            // 
            this.btnagregarinventario.BackColor = System.Drawing.Color.Black;
            this.btnagregarinventario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregarinventario.ForeColor = System.Drawing.Color.White;
            this.btnagregarinventario.Location = new System.Drawing.Point(536, 548);
            this.btnagregarinventario.Name = "btnagregarinventario";
            this.btnagregarinventario.Size = new System.Drawing.Size(140, 48);
            this.btnagregarinventario.TabIndex = 22;
            this.btnagregarinventario.Text = "Agregar";
            this.btnagregarinventario.UseVisualStyleBackColor = false;
            // 
            // btneliminarinventario
            // 
            this.btneliminarinventario.BackColor = System.Drawing.Color.Black;
            this.btneliminarinventario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneliminarinventario.ForeColor = System.Drawing.Color.White;
            this.btneliminarinventario.Location = new System.Drawing.Point(750, 548);
            this.btneliminarinventario.Name = "btneliminarinventario";
            this.btneliminarinventario.Size = new System.Drawing.Size(140, 48);
            this.btneliminarinventario.TabIndex = 23;
            this.btneliminarinventario.Text = "Eliminar";
            this.btneliminarinventario.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(289, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(700, 32);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 45);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // FRMIVENTARIO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1005, 652);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btneliminarinventario);
            this.Controls.Add(this.btnagregarinventario);
            this.Controls.Add(this.btnmodificarinventario);
            this.Controls.Add(this.btnguardarinventario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cmbxestadoinventario);
            this.Controls.Add(this.cmbxcategoriainventario);
            this.Controls.Add(this.txtfechinventario);
            this.Controls.Add(this.txtventainventario);
            this.Controls.Add(this.txtpreciocompra);
            this.Controls.Add(this.txtcantidadinventario);
            this.Controls.Add(this.txtnomproducto);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtidinventario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FRMIVENTARIO";
            this.Text = "IVENTARIO";
            this.Load += new System.EventHandler(this.FRMIVENTARIO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtidinventario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtnomproducto;
        private System.Windows.Forms.TextBox txtcantidadinventario;
        private System.Windows.Forms.TextBox txtpreciocompra;
        private System.Windows.Forms.TextBox txtventainventario;
        private System.Windows.Forms.TextBox txtfechinventario;
        private System.Windows.Forms.ComboBox cmbxcategoriainventario;
        private System.Windows.Forms.ComboBox cmbxestadoinventario;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnguardarinventario;
        private System.Windows.Forms.Button btnmodificarinventario;
        private System.Windows.Forms.Button btnagregarinventario;
        private System.Windows.Forms.Button btneliminarinventario;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}